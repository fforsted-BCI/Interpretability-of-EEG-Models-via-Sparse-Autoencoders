# ============================================================================
# RUN ALL BLOCKS 1-10 IN ONE SHARED PYTHON NAMESPACE
# ============================================================================
#
# In Colab/Jupyter, set PIPELINE_CODE_DIR to the directory containing this
# package, then execute this file with:
#
#   exec(open(f"{PIPELINE_CODE_DIR}/RUN_ALL_BLOCKS_1_TO_10.py").read(), globals())
#
# This runner deliberately uses exec(..., globals()) so every block sees the
# validated exports of the previous block exactly as notebook cells would.
# ============================================================================

import os, sys

PIPELINE_CODE_DIR = str(globals().get(
    "PIPELINE_CODE_DIR",
    os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else "."
))
if PIPELINE_CODE_DIR not in sys.path:
    sys.path.insert(0, PIPELINE_CODE_DIR)

_BLOCKS = [
    "PIPELINE_CONFIG.py",
    "Block1_SessionAware_Preprocessing_v2_2_DUAL_2CLASS_4CLASS.py",
    "Block2_SessionSafe_DualModel_v6_DUAL_2CLASS_4CLASS.py",
    "Block3_TrainingSession_CV_v4_DUAL_2CLASS_4CLASS.py",
    "Block4_IndependentSession_ExactRunStratified_v3_MULTICLASS.py",
    "Block5_BHFDR_CompetenceSelection_v3_MULTICLASS.py",
    "Block6_SharedRepresentation_v2_DUAL_2CLASS_4CLASS.py",
    "Block7_TopKSAE_v2_DUAL_2CLASS_4CLASS.py",
    "Block8_ClassSelectivity_v2_MULTICLASS_OMNIBUS.py",
    "Block9_Physiology_v3_MULTICLASS_CLASS_SPECIFIC.py",
    "Block10_LatentCausalIntervention_v3_MULTICLASS.py",
]

for _name in _BLOCKS:
    _path = os.path.join(PIPELINE_CODE_DIR, _name)
    if not os.path.isfile(_path):
        raise FileNotFoundError(_path)
    print("\n" + "#"*118)
    print(f"RUNNING: {_name}")
    print("#"*118)
    with open(_path, "r", encoding="utf-8") as _f:
        _src = _f.read()
    exec(compile(_src, _path, "exec"), globals())

print("\n" + "="*118)
print("BLOCKS 1-10 COMPLETED")
print(f"Class mode   : {B1_N_CLASSES} -> {B1_CLASSES}")
print(f"Model option : {B2_MODEL_OPTION} -> {B2_MODEL_NAME}")
print(f"Block-9 supported features : {list(B9_PHYSIO_SUPPORTED_FEATURE_IDS)}")
print(f"Block-10 causal PASS       : {list(B10_CAUSAL_SUPPORTED_FEATURE_IDS)}")
print("="*118)
