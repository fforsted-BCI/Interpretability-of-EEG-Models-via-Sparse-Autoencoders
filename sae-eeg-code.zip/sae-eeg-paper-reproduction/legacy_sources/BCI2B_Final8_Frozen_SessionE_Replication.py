# =============================================================================
# BCI IV-2b — FINAL-8 FROZEN SESSION-E FEATURE-LEVEL REPLICATION
# =============================================================================
# Run AFTER the current BCI-IV-2b Blocks 6-8 (and preferably the full pipeline)
# in the SAME notebook/runtime.
#
# Scientific boundary:
#   - final feature IDs and their Session-T preferences are frozen below
#   - shared CIACNet representation is frozen
#   - SAE dictionary is frozen
#   - Session-E is transformed only; no refitting/reselection/tuning on E
#   - permutation inference is restricted within Session-E subject x run
#   - BH-FDR family = exactly the 8 frozen final features
#
# Required globals from the current 2b pipeline:
#   B7_F_T, B7_FEATURE_IDS, B7_Y_T, B7_SID_T
#   B6_EMB_E, B6_Y_E, B6_SID_E, B6_RUN_E
#   b7_transform
# Optional:
#   B8_FEATURE_SELECTIVITY_DF (used to add Session-T AUROC/d to extended table)
#   B7_OUT_DIR
# =============================================================================

from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

# -------------------------------------------------------------------------
# 0. Frozen publication family — DO NOT change after looking at Session-E
# -------------------------------------------------------------------------
FINAL8 = [
    "F0029", "F0015", "F0041", "F0095",
    "F0024", "F0032", "F0088", "F0045",
]

PREFERENCE_T = {
    "F0029": "right_hand",
    "F0015": "right_hand",
    "F0041": "left_hand",
    "F0095": "left_hand",
    "F0024": "right_hand",
    "F0032": "left_hand",
    "F0088": "left_hand",
    "F0045": "left_hand",
}

N_PERM = 9999
N_BOOT = 5000
ALPHA = 0.05
SEED = 20261006
MIN_CONSISTENCY = 0.625

# -------------------------------------------------------------------------
# 1. Contract checks
# -------------------------------------------------------------------------
required = [
    "B7_F_T", "B7_FEATURE_IDS", "B7_Y_T", "B7_SID_T",
    "B6_EMB_E", "B6_Y_E", "B6_SID_E", "B6_RUN_E",
    "b7_transform",
]
missing = [x for x in required if x not in globals()]
if missing:
    raise RuntimeError("Missing required upstream variables: " + ", ".join(missing))

ACT_T = np.asarray(B7_F_T, dtype=float)
FEATURE_IDS = np.asarray(B7_FEATURE_IDS).astype(str)
Y_T = np.asarray(B7_Y_T, dtype=int).reshape(-1)
SID_T = np.asarray(B7_SID_T, dtype=int).reshape(-1)

EMB_E = np.asarray(B6_EMB_E, dtype=np.float32)
Y_E = np.asarray(B6_Y_E, dtype=int).reshape(-1)
SID_E = np.asarray(B6_SID_E, dtype=int).reshape(-1)
RUN_E = np.asarray(B6_RUN_E).astype(str).reshape(-1)

if EMB_E.ndim != 2 or len(EMB_E) == 0:
    raise RuntimeError(
        "B6_EMB_E is empty. Session-E embeddings must be extracted with the "
        "frozen Block-6 model before running this cell."
    )

if not all(len(x) == len(EMB_E) for x in (Y_E, SID_E, RUN_E)):
    raise RuntimeError("Session-E embeddings, labels, subjects, and runs are not aligned.")

if ACT_T.ndim != 2 or ACT_T.shape[1] != len(FEATURE_IDS):
    raise RuntimeError("B7_F_T / B7_FEATURE_IDS dimension mismatch.")

feature_to_idx = {fid: i for i, fid in enumerate(FEATURE_IDS)}
not_found = [fid for fid in FINAL8 if fid not in feature_to_idx]
if not_found:
    raise RuntimeError(
        "Final feature IDs are not present in the CURRENT Block-7 dictionary: "
        + ", ".join(not_found)
    )

# Frozen application of the CURRENT Session-T SAE to Session-E.
ACT_E = np.asarray(
    b7_transform(EMB_E, return_reconstruction=False)["activations"],
    dtype=float,
)
if ACT_E.shape != (len(EMB_E), ACT_T.shape[1]):
    raise RuntimeError(
        f"Session-E SAE activation shape {ACT_E.shape} does not match "
        f"expected {(len(EMB_E), ACT_T.shape[1])}."
    )

# -------------------------------------------------------------------------
# 2. Statistics
# -------------------------------------------------------------------------
def _oriented_auc(y, a, preference):
    y = np.asarray(y, int)
    a = np.asarray(a, float)
    if len(np.unique(y)) < 2:
        return np.nan
    # Pipeline convention: class 1 = right hand, class 0 = left hand.
    if preference == "right_hand":
        return float(roc_auc_score(y, a))
    elif preference == "left_hand":
        return float(roc_auc_score(1 - y, a))
    raise ValueError(preference)

def _signed_cohen_d_right_minus_left(y, a):
    y = np.asarray(y, int)
    a = np.asarray(a, float)
    x_r = a[y == 1]
    x_l = a[y == 0]
    if len(x_r) < 2 or len(x_l) < 2:
        return np.nan
    vr = np.var(x_r, ddof=1)
    vl = np.var(x_l, ddof=1)
    denom_df = len(x_r) + len(x_l) - 2
    if denom_df <= 0:
        return np.nan
    sp2 = ((len(x_r)-1)*vr + (len(x_l)-1)*vl) / denom_df
    if not np.isfinite(sp2) or sp2 <= 0:
        return np.nan
    return float((np.mean(x_r) - np.mean(x_l)) / np.sqrt(sp2))

def _subject_metrics(y, sid, a, preference):
    rows = []
    for s in np.unique(sid):
        m = sid == s
        if len(np.unique(y[m])) < 2:
            continue
        auc = _oriented_auc(y[m], a[m], preference)
        d = _signed_cohen_d_right_minus_left(y[m], a[m])
        rows.append((int(s), auc, d))
    return rows

def _equal_subject_auc(y, sid, a, preference):
    vals = [r[1] for r in _subject_metrics(y, sid, a, preference)
            if np.isfinite(r[1])]
    return float(np.mean(vals)) if vals else np.nan

def _mean_subject_d(y, sid, a):
    vals = [r[2] for r in _subject_metrics(y, sid, a, "right_hand")
            if np.isfinite(r[2])]
    return float(np.mean(vals)) if vals else np.nan

def _subject_consistency(y, sid, a, preference):
    metrics = _subject_metrics(y, sid, a, preference)
    ds = np.array([r[2] for r in metrics if np.isfinite(r[2])], float)
    if len(ds) == 0:
        return np.nan
    if preference == "right_hand":
        return float(np.mean(ds > 0))
    return float(np.mean(ds < 0))

def _bootstrap_subject_auc(y, sid, a, preference, n_boot, rng):
    subjects = np.unique(sid)
    by_subj = {}
    for s in subjects:
        m = sid == s
        if len(np.unique(y[m])) < 2:
            continue
        by_subj[int(s)] = _oriented_auc(y[m], a[m], preference)

    vals = np.array(list(by_subj.values()), float)
    vals = vals[np.isfinite(vals)]
    if len(vals) < 2:
        return np.nan, np.nan

    boot = np.empty(n_boot, float)
    for b in range(n_boot):
        sample = rng.choice(vals, size=len(vals), replace=True)
        boot[b] = np.mean(sample)
    return tuple(np.quantile(boot, [0.025, 0.975]).astype(float))

def _permutation_p_subject_run(y, sid, run, a, preference, n_perm, rng):
    obs = _equal_subject_auc(y, sid, a, preference)

    # Restricted exchangeability blocks: subject x run.
    groups = []
    for s in np.unique(sid):
        for r in np.unique(run[sid == s]):
            idx = np.where((sid == s) & (run == r))[0]
            if len(idx) > 1:
                groups.append(idx)

    null = np.empty(n_perm, float)
    y_perm = y.copy()

    for b in range(n_perm):
        y_perm[:] = y
        for idx in groups:
            y_perm[idx] = rng.permutation(y[idx])
        null[b] = _equal_subject_auc(y_perm, sid, a, preference)

    null = null[np.isfinite(null)]
    if len(null) == 0 or not np.isfinite(obs):
        return np.nan
    return float((1 + np.sum(null >= obs)) / (len(null) + 1))

def _bh_fdr(p):
    p = np.asarray(p, float)
    q = np.full_like(p, np.nan)
    valid = np.isfinite(p)
    pv = p[valid]
    if len(pv) == 0:
        return q

    order = np.argsort(pv)
    ranked = pv[order]
    m = len(ranked)
    adj = ranked * m / np.arange(1, m + 1)
    adj = np.minimum.accumulate(adj[::-1])[::-1]
    adj = np.minimum(adj, 1.0)

    tmp = np.empty(m, float)
    tmp[order] = adj
    q[valid] = tmp
    return q

# -------------------------------------------------------------------------
# 3. Frozen Session-E evaluation
# -------------------------------------------------------------------------
rows = []
pvals = []
rng_master = np.random.default_rng(SEED)

for fid in FINAL8:
    j = feature_to_idx[fid]
    pref = PREFERENCE_T[fid]
    aE = ACT_E[:, j]

    # deterministic per-feature RNG
    frng = np.random.default_rng(rng_master.integers(0, 2**32 - 1))

    auc_e = _equal_subject_auc(Y_E, SID_E, aE, pref)
    d_e = _mean_subject_d(Y_E, SID_E, aE)
    ci_lo, ci_hi = _bootstrap_subject_auc(
        Y_E, SID_E, aE, pref, N_BOOT, frng
    )
    consist = _subject_consistency(Y_E, SID_E, aE, pref)
    p = _permutation_p_subject_run(
        Y_E, SID_E, RUN_E, aE, pref, N_PERM, frng
    )

    rows.append({
        "Feature": fid,
        "Preference_T": pref,
        "AUROC_E": auc_e,
        "Cohens_d_E_right_minus_left": d_e,
        "CI95_E_lo": ci_lo,
        "CI95_E_hi": ci_hi,
        "p_perm_E": p,
        "Subj_consist_E": consist,
    })
    pvals.append(p)

df = pd.DataFrame(rows)
df["qBH_E"] = _bh_fdr(pvals)

# Frozen direction must agree with Session-T preference.
direction_ok = []
for _, r in df.iterrows():
    if r["Preference_T"] == "right_hand":
        direction_ok.append(bool(r["Cohens_d_E_right_minus_left"] > 0))
    else:
        direction_ok.append(bool(r["Cohens_d_E_right_minus_left"] < 0))
df["Direction_preserved"] = direction_ok

# Conservative replication flag consistent with the logic used in the paper:
# significant after BH-FDR + CI above chance + preserved direction +
# majority/robust subject-level directional consistency.
df["Replicated"] = (
    (df["qBH_E"] < ALPHA)
    & (df["CI95_E_lo"] > 0.50)
    & (df["Direction_preserved"])
    & (df["Subj_consist_E"] >= MIN_CONSISTENCY)
)

# -------------------------------------------------------------------------
# 4. Add authoritative Session-T values when available
# -------------------------------------------------------------------------
extended = df.copy()

if "B8_FEATURE_SELECTIVITY_DF" in globals():
    tdf = pd.DataFrame(B8_FEATURE_SELECTIVITY_DF).copy()
    needed = {
        "feature_id",
        "pooled_auc_oriented",
        "mean_subject_cohen_d_right_minus_left",
    }
    if needed.issubset(tdf.columns):
        tdf = tdf[list(needed)].drop_duplicates("feature_id")
        tdf = tdf.rename(columns={
            "feature_id": "Feature",
            "pooled_auc_oriented": "AUROC_T",
            "mean_subject_cohen_d_right_minus_left": "Cohens_d_T_right_minus_left",
        })
        extended = tdf.merge(df, on="Feature", how="right")

# -------------------------------------------------------------------------
# 5. display table
# -------------------------------------------------------------------------
paper = df[[
    "Feature", "AUROC_E", "Cohens_d_E_right_minus_left",
    "CI95_E_lo", "CI95_E_hi", "qBH_E", "Subj_consist_E", "Replicated"
]].copy()

paper["95% CI_E"] = paper.apply(
    lambda r: f"[{r['CI95_E_lo']:.3f}, {r['CI95_E_hi']:.3f}]",
    axis=1
)
paper["AUROC_E"] = paper["AUROC_E"].map(lambda x: f"{x:.3f}")
paper["Cohens_d_E_right_minus_left"] = paper[
    "Cohens_d_E_right_minus_left"
].map(lambda x: f"{x:.2f}")
paper["qBH_E"] = paper["qBH_E"].map(
    lambda x: "<0.001" if x < 0.001 else f"{x:.4f}"
)
paper["Subj_consist_E"] = paper["Subj_consist_E"].map(lambda x: f"{x:.3f}")
paper["Replicated"] = paper["Replicated"].map({True: "✓", False: "—"})

paper = paper.rename(columns={
    "AUROC_E": "AUROC_E",
    "Cohens_d_E_right_minus_left": "Cohen's d_E",
    "qBH_E": "q_BH",
    "Subj_consist_E": "Subj. consist.",
})

paper = paper[[
    "Feature", "AUROC_E", "Cohen's d_E",
    "95% CI_E", "q_BH", "Subj. consist.", "Replicated"
]]

# -------------------------------------------------------------------------
# 6. Save
# -------------------------------------------------------------------------
base = Path(str(globals().get("B7_OUT_DIR", ".")))
out_dir = base / "final8_sessionE_replication"
out_dir.mkdir(parents=True, exist_ok=True)

df.to_csv(out_dir / "BCI2B_final8_sessionE_replication_full.csv", index=False)
extended.to_csv(out_dir / "BCI2B_final8_T_E_replication_extended.csv", index=False)
paper.to_csv(out_dir / "BCI2B_final8_sessionE_replication_manuscript.csv", index=False)

try:
    latex = paper.to_latex(
        index=False,
        escape=False,
        caption=(
            "Session-E replication of the eight Session-T selected features "
            "(BCI-IV-2b)."
        ),
        label="tab:bci2b_sessionE_replication",
    )
    (out_dir / "BCI2B_final8_sessionE_replication_table.tex").write_text(
        latex, encoding="utf-8"
    )
except Exception as exc:
    print("LaTeX export skipped:", exc)

print("=" * 120)
print("BCI IV-2b — FINAL-8 FROZEN SESSION-E FEATURE-LEVEL REPLICATION")
print("=" * 120)
print(f"Frozen features       : {FINAL8}")
print(f"Session-E trials      : {len(Y_E)}")
print(f"Session-E subjects    : {np.unique(SID_E).tolist()}")
print(f"Permutations          : {N_PERM}")
print(f"Bootstrap resamples   : {N_BOOT}")
print("BH-FDR family         : exactly 8 frozen hypotheses")
print("SAE refit on E        : NO")
print("Feature selection on E: NO")
print("Preference reset on E : NO")
print("-" * 120)
print(paper.to_string(index=False))
print("-" * 120)
print("Saved to:", out_dir)
print("=" * 120)
