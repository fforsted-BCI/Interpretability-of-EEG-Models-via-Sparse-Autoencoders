# =============================================================================
# BCI IV-2a — FROZEN SESSION-E FEATURE-LEVEL REPLICATION
# =============================================================================
# Scientific question
# -------------------
# Do the EXACT SAE features discovered/selected on Session-T retain their
# pre-specified LH/RH class information on Session-E when:
#   * the shared CIACNet representation is frozen,
#   * the SAE dictionary is frozen,
#   * the feature family is frozen,
#   * feature preference/direction is frozen from Session-T,
#   * no Session-E feature search, re-ranking, threshold tuning, or re-selection
#     is permitted?
#
# Frozen BCI-IV-2a feature family:
#   F0003 -> right hand
#   F0020 -> left hand
#   F0070 -> left hand
#   F0078 -> left hand
#
# Primary replication test
# ------------------------
# For each feature j, fit a nuisance model on Session-T only:
#       F_j ~ F_-j
# using ridge regression. Ridge alpha is chosen by subject-LOSO on Session-T.
# Apply the frozen nuisance model to Session-E and form:
#       R_E,j = F_E,j - Ehat_T[F_j | F_-j]
# Then test whether the oriented residual AUC on Session-E is > 0.5.
#
# Secondary replication test
# --------------------------
# Raw frozen-feature oriented AUC on Session-E using the SAME Session-T-defined
# preferred class.
#
# Inference
# ---------
#   * equal-subject mean AUC is the group statistic
#   * 5,000 subject bootstrap resamples for 95% CI
#   * 9,999 label permutations restricted within Session-E subject x run
#   * BH-FDR over EXACTLY the four pre-specified frozen hypotheses
#   * no E-based candidate selection
#
# Run requirements
# ----------------
# Recommended: run old_release_b6_functional_exact_recovery_v5.py first.
# This script can then use the live OLD_* variables directly.
#
# It can also load the saved recovery NPZ if B12A_RECOVERY_NPZ or
# OLD_RECOVERY_NPZ points to:
#   old_frozen_dictionary_sessionE_activations.npz
#
# RELEASE_DIR must point to the frozen Blocks 1–11 release so that exact
# Session-T all-latent SAE activations can be loaded from:
#   RELEASE_DIR/block7_identity/block7_sae_activations.npz
# =============================================================================

from __future__ import annotations

import os
import json
import hashlib
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

try:
    from scipy.stats import rankdata
except Exception as exc:
    raise RuntimeError("scipy is required for the replication analysis.") from exc


# =============================================================================
# 0. PRE-SPECIFIED CONFIGURATION — DO NOT TUNE FROM SESSION-E
# =============================================================================

B12A_CODE_VERSION = "2026.09-bci2a-frozen-sessionE-feature-replication-v1.0"
B12A_ALPHA = 0.05
B12A_N_PERMUTATIONS = int(globals().get("B12A_N_PERMUTATIONS", 9999))
B12A_N_BOOTSTRAP = int(globals().get("B12A_N_BOOTSTRAP", 5000))
B12A_MIN_VALID_SUBJECTS = 6
B12A_MIN_POSITIVE_SUBJECT_FRACTION = 0.625
B12A_RIDGE_ALPHA_GRID = tuple(
    float(v)
    for v in globals().get(
        "B12A_RIDGE_ALPHA_GRID",
        (1e-3, 1e-2, 1e-1, 1.0, 10.0),
    )
)
B12A_PREDICTION_CLIP_Q = float(globals().get("B12A_PREDICTION_CLIP_Q", 0.995))
B12A_SEED = int(globals().get("B12A_SEED", 20260921))
B12A_ACTIVE_EPS = float(globals().get("B12A_ACTIVE_EPS", 1e-10))
B12A_FIGURE_DPI = int(globals().get("B12A_FIGURE_DPI", 600))

# Keep this True for the historical frozen release unless/until competency has
# been rebuilt exclusively from Session-T. It changes wording/provenance only;
# it does NOT change any statistic.
B12A_UPSTREAM_E_USED_FOR_COHORT_SELECTION = bool(
    globals().get("B12A_UPSTREAM_E_USED_FOR_COHORT_SELECTION", True)
)

B12A_FROZEN_FEATURE_IDS = np.asarray(
    ["F0003", "F0020", "F0070", "F0078"], dtype=str
)
B12A_FROZEN_FEATURE_INDICES = np.asarray([3, 20, 70, 78], dtype=np.int64)

# Frozen from Session-T discovery. NEVER infer/reverse these directions on E.
B12A_PREFERENCE = {
    "F0003": "right_hand",
    "F0020": "left_hand",
    "F0070": "left_hand",
    "F0078": "left_hand",
}
B12A_PREF_LABEL = {
    "F0003": 1,
    "F0020": 0,
    "F0070": 0,
    "F0078": 0,
}

if B12A_N_PERMUTATIONS < 999:
    raise ValueError("B12A_N_PERMUTATIONS must be >= 999.")
if B12A_N_BOOTSTRAP < 999:
    raise ValueError("B12A_N_BOOTSTRAP must be >= 999.")
if any(a <= 0 for a in B12A_RIDGE_ALPHA_GRID):
    raise ValueError("All ridge alpha candidates must be > 0.")
if not (0.90 <= B12A_PREDICTION_CLIP_Q < 1.0):
    raise ValueError("B12A_PREDICTION_CLIP_Q must lie in [0.90,1).")


# =============================================================================
# 1. HELPERS
# =============================================================================

def _bh_fdr(p_values):
    p = np.asarray(p_values, dtype=np.float64)
    q = np.full(p.shape, np.nan, dtype=np.float64)
    good = np.isfinite(p)
    if not np.any(good):
        return q
    idx = np.flatnonzero(good)
    vals = p[idx]
    order = np.argsort(vals, kind="mergesort")
    ranked = vals[order]
    m = len(ranked)
    adj = ranked * m / np.arange(1, m + 1, dtype=np.float64)
    adj = np.minimum.accumulate(adj[::-1])[::-1]
    adj = np.clip(adj, 0.0, 1.0)
    back = np.empty_like(adj)
    back[order] = adj
    q[idx] = back
    return q


def _auc_from_scores(y_binary, score):
    """Tie-aware AUC via Mann-Whitney rank-sum."""
    y_binary = np.asarray(y_binary, dtype=np.int64).reshape(-1)
    score = np.asarray(score, dtype=np.float64).reshape(-1)
    good = np.isfinite(score)
    y_binary = y_binary[good]
    score = score[good]
    n1 = int(np.sum(y_binary == 1))
    n0 = int(np.sum(y_binary == 0))
    if n1 < 1 or n0 < 1:
        return np.nan
    ranks = rankdata(score, method="average")
    r1 = float(np.sum(ranks[y_binary == 1]))
    u1 = r1 - n1 * (n1 + 1.0) / 2.0
    return float(u1 / (n1 * n0))


def _subject_auc_vector(scores, y, sid, pref_labels, subjects):
    scores = np.asarray(scores, dtype=np.float64)
    y = np.asarray(y, dtype=np.int64).reshape(-1)
    sid = np.asarray(sid).reshape(-1)
    pref_labels = np.asarray(pref_labels, dtype=np.int64).reshape(-1)
    subjects = np.asarray(subjects).reshape(-1)

    if scores.ndim == 1:
        scores = scores[:, None]
    if scores.shape[0] != len(y):
        raise ValueError("scores/y row mismatch")
    if scores.shape[1] != len(pref_labels):
        raise ValueError("scores/preference width mismatch")

    out = np.full((len(subjects), scores.shape[1]), np.nan, dtype=np.float64)
    for si, s in enumerate(subjects):
        m = sid == s
        ys = y[m]
        for j, pref in enumerate(pref_labels):
            y_pref = (ys == int(pref)).astype(np.int64)
            out[si, j] = _auc_from_scores(y_pref, scores[m, j])
    return out


def _bootstrap_subject_mean_ci(subject_metric, n_boot, seed):
    subject_metric = np.asarray(subject_metric, dtype=np.float64)
    if subject_metric.ndim == 1:
        subject_metric = subject_metric[:, None]
    rng = np.random.default_rng(seed)
    n_s, n_f = subject_metric.shape
    boot = np.full((n_boot, n_f), np.nan, dtype=np.float64)
    for b in range(n_boot):
        idx = rng.integers(0, n_s, size=n_s)
        boot[b] = np.nanmean(subject_metric[idx], axis=0)
    lo = np.nanquantile(boot, 0.025, axis=0)
    hi = np.nanquantile(boot, 0.975, axis=0)
    return lo, hi


def _ridge_fit_predict(Xtr, ytr, Xte, alpha):
    """Ridge nuisance model with T-learned standardization only."""
    Xtr = np.asarray(Xtr, dtype=np.float64)
    Xte = np.asarray(Xte, dtype=np.float64)
    ytr = np.asarray(ytr, dtype=np.float64).reshape(-1)

    mu = Xtr.mean(axis=0)
    sd = Xtr.std(axis=0, ddof=0)
    keep = np.isfinite(sd) & (sd > 1e-10)
    if not np.any(keep):
        return np.full(len(Xte), float(np.mean(ytr))), 0

    A = (Xtr[:, keep] - mu[keep]) / sd[keep]
    B = (Xte[:, keep] - mu[keep]) / sd[keep]

    ym = float(np.mean(ytr))
    yc = ytr - ym
    n = max(1, len(ytr))
    M = (A.T @ A) / n + float(alpha) * np.eye(A.shape[1], dtype=np.float64)
    rhs = (A.T @ yc) / n
    try:
        beta = np.linalg.solve(M, rhs)
    except np.linalg.LinAlgError:
        beta = np.linalg.pinv(M) @ rhs
    return np.asarray(ym + B @ beta, dtype=np.float64), int(np.sum(keep))


def _choose_alpha_T_only(X, y, sid):
    """Choose nuisance ridge alpha by Session-T subject-LOSO normalized MSE."""
    X = np.asarray(X, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64).reshape(-1)
    sid = np.asarray(sid).reshape(-1)
    subjects = np.unique(sid)
    candidates = []

    for alpha in B12A_RIDGE_ALPHA_GRID:
        losses = []
        for s in subjects:
            va = sid == s
            tr = sid != s
            if np.sum(tr) < 20 or np.sum(va) < 2:
                continue
            pred, _ = _ridge_fit_predict(X[tr], y[tr], X[va], alpha)
            scale = float(np.var(y[tr]))
            if scale <= 1e-12:
                scale = 1.0
            losses.append(float(np.mean((y[va] - pred) ** 2) / scale))
        if losses:
            candidates.append((float(np.mean(losses)), float(alpha)))

    if not candidates:
        return 1.0, "fallback_no_valid_T_only_inner_folds"
    candidates.sort(key=lambda z: (z[0], z[1]))
    return float(candidates[0][1]), "T_only_subject_LOSO_normalized_MSE"


def _hash_array(x):
    a = np.ascontiguousarray(np.asarray(x))
    return hashlib.sha256(a.view(np.uint8)).hexdigest()


# =============================================================================
# 2. RESOLVE FROZEN RELEASE + SESSION-T ALL-LATENT ACTIVATIONS
# =============================================================================

if "RELEASE_DIR" not in globals():
    raise RuntimeError(
        "Set RELEASE_DIR to the frozen Blocks 1–11 BCI-IV-2a release before running this analysis."
    )

release_dir = Path(str(globals()["RELEASE_DIR"])).expanduser().resolve()
b7_npz = release_dir / "block7_identity" / "block7_sae_activations.npz"
identity_npz = release_dir / "snapshots" / "final_feature_identity.npz"

for p in (b7_npz, identity_npz):
    if not p.is_file():
        raise FileNotFoundError(p)

with np.load(identity_npz, allow_pickle=False) as z:
    final_ids = np.asarray(z["final_feature_ids"]).astype(str).reshape(-1)
    final_idx = np.asarray(z["final_feature_indices"], dtype=np.int64).reshape(-1)

if final_ids.tolist() != B12A_FROZEN_FEATURE_IDS.tolist():
    raise RuntimeError(
        "Frozen release feature IDs differ from the pre-specified family: "
        f"{final_ids.tolist()}"
    )
if final_idx.tolist() != B12A_FROZEN_FEATURE_INDICES.tolist():
    raise RuntimeError(
        "Frozen release feature indices differ from [3,20,70,78]: "
        f"{final_idx.tolist()}"
    )

with np.load(b7_npz, allow_pickle=False) as z:
    required = {"T_y", "T_sid", "T_run", "T_uid", "act_T"}
    missing = sorted(required - set(z.files))
    if missing:
        raise RuntimeError("Frozen Block-7 activation artifact missing: " + ", ".join(missing))
    T_Y = np.asarray(z["T_y"], dtype=np.int64).reshape(-1)
    T_SID = np.asarray(z["T_sid"], dtype=np.int64).reshape(-1)
    T_RUN = np.asarray(z["T_run"]).astype(str).reshape(-1)
    T_UID = np.asarray(z["T_uid"]).astype(str).reshape(-1)
    ACT_T = np.asarray(z["act_T"], dtype=np.float64)

if ACT_T.ndim != 2 or ACT_T.shape[1] <= int(B12A_FROZEN_FEATURE_INDICES.max()):
    raise RuntimeError(f"Invalid Session-T SAE activation shape: {ACT_T.shape}")
if ACT_T.shape[0] != len(T_Y) or len(T_Y) != len(T_SID):
    raise RuntimeError("Session-T activation/label/subject rows are misaligned.")
if set(np.unique(T_Y).tolist()) != {0, 1}:
    raise RuntimeError(f"Expected binary Session-T labels {{0,1}}, got {np.unique(T_Y).tolist()}.")


# =============================================================================
# 3. RESOLVE SESSION-E FROZEN ACTIVATIONS
# =============================================================================

runtime_ready = all(
    k in globals()
    for k in (
        "OLD_B7_ACT_E_RECOVERED",
        "OLD_E_Y",
        "OLD_E_SID",
        "OLD_E_RUN",
        "OLD_E_UID",
        "OLD_FINAL_FEATURE_IDS",
        "OLD_FINAL_FEATURE_INDICES",
    )
)

if runtime_ready:
    ACT_E = np.asarray(globals()["OLD_B7_ACT_E_RECOVERED"], dtype=np.float64)
    E_Y = np.asarray(globals()["OLD_E_Y"], dtype=np.int64).reshape(-1)
    E_SID = np.asarray(globals()["OLD_E_SID"]).reshape(-1)
    E_RUN = np.asarray(globals()["OLD_E_RUN"]).astype(str).reshape(-1)
    E_UID = np.asarray(globals()["OLD_E_UID"]).astype(str).reshape(-1)
    e_ids = np.asarray(globals()["OLD_FINAL_FEATURE_IDS"]).astype(str).reshape(-1)
    e_idx = np.asarray(globals()["OLD_FINAL_FEATURE_INDICES"], dtype=np.int64).reshape(-1)
    activation_source = "live OLD_* outputs from exact frozen B6/B7 recovery"
    recovery_path = str(globals().get("OLD_RECOVERY_NPZ", ""))
else:
    recovery_path = str(
        globals().get(
            "B12A_RECOVERY_NPZ",
            globals().get("OLD_RECOVERY_NPZ", ""),
        )
    ).strip()
    if not recovery_path:
        raise RuntimeError(
            "Run old_release_b6_functional_exact_recovery_v5.py first, or set "
            "B12A_RECOVERY_NPZ to old_frozen_dictionary_sessionE_activations.npz."
        )
    rp = Path(recovery_path).expanduser().resolve()
    if not rp.is_file():
        raise FileNotFoundError(rp)
    with np.load(rp, allow_pickle=False) as z:
        required = {
            "E_y", "E_sid", "E_run", "E_uid", "act_E",
            "final_feature_ids", "final_feature_indices",
        }
        missing = sorted(required - set(z.files))
        if missing:
            raise RuntimeError("Recovery NPZ missing: " + ", ".join(missing))
        ACT_E = np.asarray(z["act_E"], dtype=np.float64)
        E_Y = np.asarray(z["E_y"], dtype=np.int64).reshape(-1)
        E_SID = np.asarray(z["E_sid"]).reshape(-1)
        E_RUN = np.asarray(z["E_run"]).astype(str).reshape(-1)
        E_UID = np.asarray(z["E_uid"]).astype(str).reshape(-1)
        e_ids = np.asarray(z["final_feature_ids"]).astype(str).reshape(-1)
        e_idx = np.asarray(z["final_feature_indices"], dtype=np.int64).reshape(-1)
    activation_source = f"saved exact frozen Session-E recovery: {rp}"

if e_ids.tolist() != B12A_FROZEN_FEATURE_IDS.tolist():
    raise RuntimeError(f"Session-E recovery feature IDs mismatch: {e_ids.tolist()}")
if e_idx.tolist() != B12A_FROZEN_FEATURE_INDICES.tolist():
    raise RuntimeError(f"Session-E recovery feature indices mismatch: {e_idx.tolist()}")
if ACT_E.ndim != 2 or ACT_E.shape[1] != ACT_T.shape[1]:
    raise RuntimeError(f"T/E SAE dictionary-width mismatch: T={ACT_T.shape}, E={ACT_E.shape}")
if ACT_E.shape[0] != len(E_Y) or len(E_Y) != len(E_SID) or len(E_Y) != len(E_RUN):
    raise RuntimeError("Session-E activation/label/subject/run rows are misaligned.")
if set(np.unique(E_Y).tolist()) != {0, 1}:
    raise RuntimeError(f"Expected binary Session-E labels {{0,1}}, got {np.unique(E_Y).tolist()}.")
if not np.isfinite(ACT_T).all() or not np.isfinite(ACT_E).all():
    raise RuntimeError("T or E SAE activations contain NaN/Inf.")

N_T, L = ACT_T.shape
N_E = ACT_E.shape[0]
subjects_E = np.unique(E_SID)
K = len(B12A_FROZEN_FEATURE_IDS)
pref_labels = np.asarray([B12A_PREF_LABEL[f] for f in B12A_FROZEN_FEATURE_IDS], dtype=np.int64)


# =============================================================================
# 4. T-ONLY NUISANCE FIT; FREEZE; APPLY TO E
# =============================================================================

RAW_E_TARGET = ACT_E[:, B12A_FROZEN_FEATURE_INDICES].copy()
E_RESID = np.full((N_E, K), np.nan, dtype=np.float64)
nuisance_rows = []

for k, (fid, j) in enumerate(zip(B12A_FROZEN_FEATURE_IDS, B12A_FROZEN_FEATURE_INDICES)):
    others = np.ones(L, dtype=bool)
    others[int(j)] = False
    X_T = ACT_T[:, others]
    y_T = ACT_T[:, int(j)]
    X_E = ACT_E[:, others]

    alpha, alpha_rule = _choose_alpha_T_only(X_T, y_T, T_SID)
    pred_E, n_predictors = _ridge_fit_predict(X_T, y_T, X_E, alpha)

    # Clip only using T-derived target activation range to reduce extreme
    # nuisance extrapolation. No E-derived clipping threshold is used.
    qlo = float(np.quantile(y_T, 1.0 - B12A_PREDICTION_CLIP_Q))
    qhi = float(np.quantile(y_T, B12A_PREDICTION_CLIP_Q))
    pred_E = np.clip(pred_E, qlo, qhi)
    E_RESID[:, k] = RAW_E_TARGET[:, k] - pred_E

    nuisance_rows.append({
        "feature_id": str(fid),
        "feature_index": int(j),
        "preference": B12A_PREFERENCE[str(fid)],
        "preferred_label": int(B12A_PREF_LABEL[str(fid)]),
        "ridge_alpha_T_only": float(alpha),
        "ridge_alpha_rule": alpha_rule,
        "n_predictors_used": int(n_predictors),
        "T_prediction_clip_lo": qlo,
        "T_prediction_clip_hi": qhi,
    })

B12A_NUISANCE_DF = pd.DataFrame(nuisance_rows)


# =============================================================================
# 5. OBSERVED SESSION-E FEATURE-LEVEL REPLICATION STATISTICS
# =============================================================================

resid_subj = _subject_auc_vector(E_RESID, E_Y, E_SID, pref_labels, subjects_E)
raw_subj = _subject_auc_vector(RAW_E_TARGET, E_Y, E_SID, pref_labels, subjects_E)

resid_auc_mean = np.nanmean(resid_subj, axis=0)
raw_auc_mean = np.nanmean(raw_subj, axis=0)
resid_n_valid = np.sum(np.isfinite(resid_subj), axis=0)
raw_n_valid = np.sum(np.isfinite(raw_subj), axis=0)
resid_pos_frac = np.nanmean(resid_subj > 0.50, axis=0)
raw_pos_frac = np.nanmean(raw_subj > 0.50, axis=0)

resid_ci_lo, resid_ci_hi = _bootstrap_subject_mean_ci(
    resid_subj, B12A_N_BOOTSTRAP, B12A_SEED + 1
)
raw_ci_lo, raw_ci_hi = _bootstrap_subject_mean_ci(
    raw_subj, B12A_N_BOOTSTRAP, B12A_SEED + 2
)

pooled_resid_auc = np.asarray([
    _auc_from_scores((E_Y == pref).astype(np.int64), E_RESID[:, k])
    for k, pref in enumerate(pref_labels)
], dtype=np.float64)
pooled_raw_auc = np.asarray([
    _auc_from_scores((E_Y == pref).astype(np.int64), RAW_E_TARGET[:, k])
    for k, pref in enumerate(pref_labels)
], dtype=np.float64)

activation_frequency_E = np.mean(RAW_E_TARGET > B12A_ACTIVE_EPS, axis=0)


# =============================================================================
# 6. SESSION-E EXCHANGEABILITY AUDIT + RESTRICTED PERMUTATION
# =============================================================================

groups = []
group_rows = []
for s in np.unique(E_SID):
    for r in np.unique(E_RUN[E_SID == s]):
        idx = np.flatnonzero((E_SID == s) & (E_RUN == r))
        labels = np.unique(E_Y[idx])
        permutable = bool(len(idx) >= 2 and len(labels) >= 2)
        group_rows.append({
            "subject": s,
            "run": str(r),
            "n_rows": int(len(idx)),
            "n_classes": int(len(labels)),
            "permutable": permutable,
        })
        if permutable:
            groups.append(idx)

B12A_EXCHANGEABILITY_DF = pd.DataFrame(group_rows)
n_permutable_rows = int(sum(len(g) for g in groups))
permutable_fraction = float(n_permutable_rows / max(1, N_E))

if len(groups) == 0:
    raise RuntimeError("No valid Session-E subject×run exchangeability blocks.")
if permutable_fraction < 0.80:
    raise RuntimeError(
        f"Only {permutable_fraction:.1%} of Session-E rows fall in valid subject×run permutation blocks."
    )

rng = np.random.default_rng(B12A_SEED)
resid_exceed = np.zeros(K, dtype=np.int64)
raw_exceed = np.zeros(K, dtype=np.int64)

for _ in range(B12A_N_PERMUTATIONS):
    yp = E_Y.copy()
    for idx in groups:
        yp[idx] = rng.permutation(yp[idx])

    perm_resid_subj = _subject_auc_vector(E_RESID, yp, E_SID, pref_labels, subjects_E)
    perm_raw_subj = _subject_auc_vector(RAW_E_TARGET, yp, E_SID, pref_labels, subjects_E)
    perm_resid_mean = np.nanmean(perm_resid_subj, axis=0)
    perm_raw_mean = np.nanmean(perm_raw_subj, axis=0)

    resid_exceed += (perm_resid_mean >= resid_auc_mean - 1e-15).astype(np.int64)
    raw_exceed += (perm_raw_mean >= raw_auc_mean - 1e-15).astype(np.int64)

resid_p = (1.0 + resid_exceed.astype(np.float64)) / (1.0 + B12A_N_PERMUTATIONS)
raw_p = (1.0 + raw_exceed.astype(np.float64)) / (1.0 + B12A_N_PERMUTATIONS)
resid_q = _bh_fdr(resid_p)
raw_q = _bh_fdr(raw_p)


# =============================================================================
# 7. PRE-SPECIFIED REPLICATION VERDICTS
# =============================================================================

resid_primary = (
    (resid_n_valid >= B12A_MIN_VALID_SUBJECTS)
    & np.isfinite(resid_auc_mean)
    & (resid_auc_mean > 0.50)
    & np.isfinite(resid_q)
    & (resid_q < B12A_ALPHA)
)
resid_robust = (
    resid_primary
    & (resid_pos_frac >= B12A_MIN_POSITIVE_SUBJECT_FRACTION)
    & np.isfinite(resid_ci_lo)
    & (resid_ci_lo > 0.50)
)

raw_primary = (
    (raw_n_valid >= B12A_MIN_VALID_SUBJECTS)
    & np.isfinite(raw_auc_mean)
    & (raw_auc_mean > 0.50)
    & np.isfinite(raw_q)
    & (raw_q < B12A_ALPHA)
)
raw_robust = (
    raw_primary
    & (raw_pos_frac >= B12A_MIN_POSITIVE_SUBJECT_FRACTION)
    & np.isfinite(raw_ci_lo)
    & (raw_ci_lo > 0.50)
)


def _grade(k):
    if bool(resid_robust[k]):
        return "ROBUST_CONDITIONAL_REPLICATION"
    if bool(resid_primary[k]):
        return "PRIMARY_CONDITIONAL_REPLICATION"
    if bool(raw_robust[k]):
        return "RAW_ROBUST_ONLY"
    if bool(raw_primary[k]):
        return "RAW_PRIMARY_ONLY"
    return "NOT_REPLICATED"


# =============================================================================
# 8. REVIEWER-READY TABLES
# =============================================================================

rows = []
for k, (fid, j) in enumerate(zip(B12A_FROZEN_FEATURE_IDS, B12A_FROZEN_FEATURE_INDICES)):
    rows.append({
        "feature_id": str(fid),
        "feature_index": int(j),
        "T_frozen_preference": B12A_PREFERENCE[str(fid)],
        "T_frozen_preferred_label": int(B12A_PREF_LABEL[str(fid)]),
        "E_activation_frequency": float(activation_frequency_E[k]),
        "E_residual_auc_equal_subject": float(resid_auc_mean[k]),
        "E_residual_auc_boot95_lo": float(resid_ci_lo[k]),
        "E_residual_auc_boot95_hi": float(resid_ci_hi[k]),
        "E_residual_auc_pooled": float(pooled_resid_auc[k]),
        "E_residual_positive_subject_fraction": float(resid_pos_frac[k]),
        "E_residual_n_valid_subjects": int(resid_n_valid[k]),
        "E_residual_perm_p": float(resid_p[k]),
        "E_residual_q_bh_4": float(resid_q[k]),
        "E_residual_primary_pass": bool(resid_primary[k]),
        "E_residual_robust_pass": bool(resid_robust[k]),
        "E_raw_auc_equal_subject": float(raw_auc_mean[k]),
        "E_raw_auc_boot95_lo": float(raw_ci_lo[k]),
        "E_raw_auc_boot95_hi": float(raw_ci_hi[k]),
        "E_raw_auc_pooled": float(pooled_raw_auc[k]),
        "E_raw_positive_subject_fraction": float(raw_pos_frac[k]),
        "E_raw_n_valid_subjects": int(raw_n_valid[k]),
        "E_raw_perm_p": float(raw_p[k]),
        "E_raw_q_bh_4": float(raw_q[k]),
        "E_raw_primary_pass": bool(raw_primary[k]),
        "E_raw_robust_pass": bool(raw_robust[k]),
        "replication_grade": _grade(k),
    })

B12A_REPLICATION_DF = pd.DataFrame(rows)

subject_rows = []
for si, s in enumerate(subjects_E):
    for k, fid in enumerate(B12A_FROZEN_FEATURE_IDS):
        subject_rows.append({
            "subject": s,
            "feature_id": str(fid),
            "preference": B12A_PREFERENCE[str(fid)],
            "E_residual_oriented_auc": float(resid_subj[si, k]) if np.isfinite(resid_subj[si, k]) else np.nan,
            "E_raw_oriented_auc": float(raw_subj[si, k]) if np.isfinite(raw_subj[si, k]) else np.nan,
        })
B12A_SUBJECT_DF = pd.DataFrame(subject_rows)


# =============================================================================
# 9. SAVE OUTPUTS
# =============================================================================

if recovery_path:
    default_parent = Path(recovery_path).expanduser().resolve().parent
else:
    default_parent = release_dir.parent

B12A_OUT_DIR = Path(
    str(globals().get("B12A_OUT_DIR", default_parent / "block12A_frozen_sessionE_feature_replication"))
).expanduser().resolve()
B12A_OUT_DIR.mkdir(parents=True, exist_ok=True)

rep_csv = B12A_OUT_DIR / "bci2a_frozen_sessionE_feature_replication.csv"
subj_csv = B12A_OUT_DIR / "bci2a_frozen_sessionE_subject_auc.csv"
nuis_csv = B12A_OUT_DIR / "bci2a_Tonly_nuisance_models.csv"
exch_csv = B12A_OUT_DIR / "bci2a_sessionE_exchangeability_blocks.csv"
manifest_json = B12A_OUT_DIR / "bci2a_frozen_sessionE_replication_manifest.json"
fig_png = B12A_OUT_DIR / "bci2a_frozen_sessionE_replication_forest_600dpi.png"
fig_pdf = B12A_OUT_DIR / "bci2a_frozen_sessionE_replication_forest.pdf"

B12A_REPLICATION_DF.to_csv(rep_csv, index=False)
B12A_SUBJECT_DF.to_csv(subj_csv, index=False)
B12A_NUISANCE_DF.to_csv(nuis_csv, index=False)
B12A_EXCHANGEABILITY_DF.to_csv(exch_csv, index=False)

# Forest plot: primary conditional residual AUC.
P = B12A_REPLICATION_DF.copy()
ypos = np.arange(len(P))
fig, ax = plt.subplots(figsize=(7.2, 4.3))
x = P["E_residual_auc_equal_subject"].to_numpy(float)
lo = P["E_residual_auc_boot95_lo"].to_numpy(float)
hi = P["E_residual_auc_boot95_hi"].to_numpy(float)
ax.errorbar(x, ypos, xerr=np.vstack([x - lo, hi - x]), fmt="o", capsize=3)
ax.axvline(0.50, linestyle="--", linewidth=1.0)
labels = [
    f"{r.feature_id} [{'PASS' if bool(r.E_residual_primary_pass) else 'FAIL'}]"
    for r in P.itertuples(index=False)
]
ax.set_yticks(ypos)
ax.set_yticklabels(labels)
ax.invert_yaxis()
ax.set_xlabel("Session-E conditional residual AUC (T-frozen preferred class)")
ax.set_ylabel("Frozen SAE feature")
ax.set_title("BCI-IV-2a frozen Session-E feature-level replication")
ax.grid(axis="x", alpha=0.25)
fig.tight_layout()
fig.savefig(fig_png, dpi=B12A_FIGURE_DPI, bbox_inches="tight")
fig.savefig(fig_pdf, bbox_inches="tight")
plt.close(fig)

manifest = {
    "code_version": B12A_CODE_VERSION,
    "release_dir": str(release_dir),
    "activation_source_E": activation_source,
    "frozen_feature_ids": B12A_FROZEN_FEATURE_IDS.tolist(),
    "frozen_feature_indices": B12A_FROZEN_FEATURE_INDICES.tolist(),
    "frozen_preferences": B12A_PREFERENCE,
    "primary_test": "T-only nuisance residual -> Session-E preferred-class AUC",
    "secondary_test": "Session-E raw frozen-feature preferred-class AUC",
    "n_T": int(N_T),
    "n_E": int(N_E),
    "E_subjects": [str(x) for x in subjects_E.tolist()],
    "T_activation_sha256": _hash_array(ACT_T),
    "E_activation_sha256": _hash_array(ACT_E),
    "candidate_selection_using_E": False,
    "preference_redefinition_using_E": False,
    "SAE_fitting_using_E": False,
    "nuisance_fitting_using_E": False,
    "nuisance_alpha_selection": "Session-T subject-LOSO only",
    "permutation": "within Session-E subject x run",
    "n_permutations": int(B12A_N_PERMUTATIONS),
    "n_bootstrap": int(B12A_N_BOOTSTRAP),
    "BH_family_size": int(K),
    "alpha": float(B12A_ALPHA),
    "min_valid_subjects": int(B12A_MIN_VALID_SUBJECTS),
    "robust_positive_subject_fraction": float(B12A_MIN_POSITIVE_SUBJECT_FRACTION),
    "upstream_E_used_for_cohort_selection": bool(B12A_UPSTREAM_E_USED_FOR_COHORT_SELECTION),
    "interpretation": (
        "selection-conditioned frozen cross-session feature replication"
        if B12A_UPSTREAM_E_USED_FOR_COHORT_SELECTION
        else "frozen cross-session feature-level confirmation with T-only upstream selection"
    ),
}
with open(manifest_json, "w", encoding="utf-8") as f:
    json.dump(manifest, f, indent=2)


# =============================================================================
# 10. FINAL REPORT
# =============================================================================

conditional_ids = B12A_REPLICATION_DF.loc[
    B12A_REPLICATION_DF["E_residual_primary_pass"], "feature_id"
].tolist()
robust_ids = B12A_REPLICATION_DF.loc[
    B12A_REPLICATION_DF["E_residual_robust_pass"], "feature_id"
].tolist()
raw_ids = B12A_REPLICATION_DF.loc[
    B12A_REPLICATION_DF["E_raw_primary_pass"], "feature_id"
].tolist()

print("=" * 152)
print("BCI IV-2a — FROZEN SESSION-E FEATURE-LEVEL REPLICATION")
print("=" * 152)
print(f"Session-T rows                         : {N_T}")
print(f"Session-E rows                         : {N_E}")
print(f"Session-E subjects                     : {len(subjects_E)} -> {subjects_E.tolist()}")
print(f"Frozen feature family                  : {B12A_FROZEN_FEATURE_IDS.tolist()}")
print(f"Session-E activation source            : {activation_source}")
print("SAE retraining using E                 : NO")
print("Feature selection using E              : NO")
print("Preference/direction redefinition E    : NO")
print("Nuisance fitting using E               : NO")
print("Nuisance alpha selection               : Session-T subject-LOSO only")
print("Primary E test                         : conditional residual preferred-class AUC")
print("Secondary E test                       : raw frozen-feature preferred-class AUC")
print("Permutation restriction                : Session-E subject x run")
print(f"Permutable rows                         : {n_permutable_rows}/{N_E} ({permutable_fraction:.1%})")
print(f"Permutations                           : {B12A_N_PERMUTATIONS}")
print(f"Bootstrap resamples                    : {B12A_N_BOOTSTRAP}")
print(f"BH-FDR family                          : EXACTLY {K} frozen hypotheses")
print(f"Conditional replication PASS           : {len(conditional_ids)} -> {conditional_ids}")
print(f"Conditional replication ROBUST         : {len(robust_ids)} -> {robust_ids}")
print(f"Raw replication PASS                   : {len(raw_ids)} -> {raw_ids}")
if B12A_UPSTREAM_E_USED_FOR_COHORT_SELECTION:
    print("Interpretation boundary                : selection-conditioned; historical Block 5 used Session-E for cohort selection")
else:
    print("Interpretation boundary                : upstream cohort selection was Session-T only")
print("-" * 152)
show = [
    "feature_id", "T_frozen_preference",
    "E_residual_auc_equal_subject", "E_residual_auc_boot95_lo", "E_residual_auc_boot95_hi",
    "E_residual_positive_subject_fraction", "E_residual_perm_p", "E_residual_q_bh_4",
    "E_residual_primary_pass", "E_residual_robust_pass",
    "E_raw_auc_equal_subject", "E_raw_q_bh_4", "E_raw_primary_pass",
    "replication_grade",
]
print(B12A_REPLICATION_DF[show].to_string(index=False))
print("-" * 152)
print(f"Replication CSV                       : {rep_csv}")
print(f"Subject-level CSV                     : {subj_csv}")
print(f"T-only nuisance-model CSV             : {nuis_csv}")
print(f"Exchangeability CSV                   : {exch_csv}")
print(f"Forest figure PNG                     : {fig_png}")
print(f"Forest figure PDF                     : {fig_pdf}")
print(f"Manifest                              : {manifest_json}")
print("=" * 152)

# Convenient exports for notebook use.
B12A_READY_FOR_REPORTING = True
B12A_CONDITIONAL_REPLICATED_IDS = np.asarray(conditional_ids, dtype=str)
B12A_CONDITIONAL_ROBUST_IDS = np.asarray(robust_ids, dtype=str)
B12A_RAW_REPLICATED_IDS = np.asarray(raw_ids, dtype=str)
