# ============================================================================
# OLD FROZEN RELEASE — FUNCTIONAL-EXACT BLOCK-6 + AUTHORITATIVE B1 RECOVERY + SESSION-E SAE REPLAY
# ============================================================================
# Purpose
# -------
# Recover Session-E activations for the ORIGINAL frozen SAE dictionary
# (including F0003/F0020/F0070/F0078) without retraining Blocks 6 or 7.
#
# This does NOT use the newer Release-v2 embeddings. It reconstructs the original
# Block-6 forward transform from the frozen Block-6 pipeline checkpoint itself:
#   Block-1 EEG -> original saved FBCSP frontend -> original saved CIACNet weights
#   -> raw 96-D embedding -> original saved T-fitted StandardScaler
# Then it requires the regenerated Session-T matrix to reproduce the exact
# Block-7 T_input_digest before Session-E is allowed through the old SAE.
#
# Fail-closed policy
# ------------------
# * No retraining.
# * No feature reselection.
# * No digest relaxation.
# * No T+E pooling.
# * The old four feature IDs are exported only if all provenance/replay gates pass.
# ============================================================================

from __future__ import annotations

import os
import json
import hashlib
from pathlib import Path
from collections import OrderedDict

import numpy as np
import pandas as pd
from scipy.signal import butter, sosfiltfilt

import torch
import torch.nn as nn


# ----------------------------------------------------------------------------
# 0. USER / RUNTIME CONFIG
# ----------------------------------------------------------------------------
# Preferred use:
#   RELEASE_DIR = r".../blocks1_11_release_v1__4d9f76bd90948810784c"
#   %run /content/old_release_b6_exact_transform_recovery.py
#
# Optional overrides (only if the recorded source path moved):
#   OLD_B6_PIPELINE_PT_OVERRIDE = r".../block6_shared_sessionT_pipeline.pt"
#   OLD_B1_ARRAYS_NPZ_OVERRIDE = r".../block1_arrays.npz"
#
# Keep exact digest gate True for publication use.
OLD_REQUIRE_EXACT_B7_T_INPUT_DIGEST = bool(
    globals().get("OLD_REQUIRE_EXACT_B7_T_INPUT_DIGEST", True)
)
if not OLD_REQUIRE_EXACT_B7_T_INPUT_DIGEST:
    raise ValueError(
        "Exact frozen B7 T_input_digest verification is mandatory for this old-lineage recovery."
    )
OLD_B6_INFER_BATCH = int(globals().get("OLD_B6_INFER_BATCH", 256))
OLD_SAVE_RECOVERY = bool(globals().get("OLD_SAVE_RECOVERY", True))

if OLD_B6_INFER_BATCH != 256:
    raise ValueError(
        "The original Block-6/Block-2 embedding extraction used batch_size=256. "
        "For exact recovery OLD_B6_INFER_BATCH must remain 256."
    )

if "RELEASE_DIR" not in globals():
    raise RuntimeError(
        "Set RELEASE_DIR to the old frozen Blocks1-11 release before running this cell."
    )

_release_dir = Path(str(globals()["RELEASE_DIR"])).expanduser().resolve()
_release_manifest_path = _release_dir / "release_manifest.json"
_b1_manifest_path = _release_dir / "manifests" / "block1_manifest.json"
_b6_manifest_path = _release_dir / "manifests" / "block6_manifest.json"
_b7_manifest_path = _release_dir / "manifests" / "block7_manifest.json"
_identity_path = _release_dir / "snapshots" / "final_feature_identity.npz"
_b7_acts_path = _release_dir / "block7_identity" / "block7_sae_activations.npz"
_b7_checkpoint_path = _release_dir / "block7_identity" / "block7_topk_sae.pt"

for _p in (
    _release_manifest_path, _b1_manifest_path, _b6_manifest_path,
    _b7_manifest_path, _identity_path, _b7_acts_path, _b7_checkpoint_path,
):
    if not _p.is_file():
        raise FileNotFoundError(f"Required old-release artifact missing: {_p}")


def _load_json(path: Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _sha256_file(path: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def _b7_digest_numeric(values) -> str:
    """Exact digest definition used by the frozen Block 7."""
    a = np.ascontiguousarray(np.asarray(values))
    h = hashlib.sha1()
    h.update(str(a.dtype).encode("utf-8"))
    h.update(repr(tuple(a.shape)).encode("utf-8"))
    h.update(a.tobytes())
    return h.hexdigest()


def _b1_fingerprint(X, y, sid, session, run, uid) -> str:
    """Exact Block-1 fingerprint used by the frozen pipeline."""
    h = hashlib.sha1()
    X = np.ascontiguousarray(X, dtype=np.float32)
    h.update(np.asarray(X.shape, dtype=np.int64).tobytes())
    h.update(np.ascontiguousarray(y, dtype=np.int64).tobytes())
    h.update(np.ascontiguousarray(sid, dtype=np.int64).tobytes())
    h.update("|".join(np.asarray(session).astype(str).tolist()).encode("utf-8"))
    h.update("|".join(np.asarray(run).astype(str).tolist()).encode("utf-8"))
    h.update("|".join(np.asarray(uid).astype(str).tolist()).encode("utf-8"))
    flat = X.reshape(-1)
    step = max(1, int(flat.size // 200_000))
    h.update(np.ascontiguousarray(flat[::step]).tobytes())
    return h.hexdigest()


_release_manifest = _load_json(_release_manifest_path)
_b1_manifest = _load_json(_b1_manifest_path)
_b6_manifest = _load_json(_b6_manifest_path)
_b7_manifest = _load_json(_b7_manifest_path)

_expected_b6_sig = str(
    (_release_manifest.get("upstream_selection_signatures", {}) or {}).get(
        "block6",
        (_release_manifest.get("selection_signatures", {}) or {}).get("B6", ""),
    )
).strip()
if not _expected_b6_sig:
    _expected_b6_sig = str(_b6_manifest.get("selection_sig", "")).strip()

_expected_b7_sig = str(
    (_release_manifest.get("upstream_selection_signatures", {}) or {}).get(
        "block7",
        (_release_manifest.get("selection_signatures", {}) or {}).get("B7", ""),
    )
).strip()
if not _expected_b7_sig:
    _expected_b7_sig = str(_b7_manifest.get("selection_sig", "")).strip()

_expected_b7_input_digest = str(
    (_b7_manifest.get("data_contract", {}) or {}).get(
        "T_input_digest",
        (_b7_manifest.get("config", {}) or {}).get("T_input_digest", ""),
    )
).strip()

if not _expected_b6_sig or not _expected_b7_sig or not _expected_b7_input_digest:
    raise RuntimeError(
        "Old frozen release is missing B6/B7 signatures or the frozen B7 T_input_digest."
    )

if str(_b6_manifest.get("selection_sig", "")) != _expected_b6_sig:
    raise RuntimeError("Frozen Block-6 manifest selection signature mismatch.")
if str(_b7_manifest.get("selection_sig", "")) != _expected_b7_sig:
    raise RuntimeError("Frozen Block-7 manifest selection signature mismatch.")


# ----------------------------------------------------------------------------
# 1. RESOLVE A BLOCK-6 CHECKPOINT CANDIDATE, THEN PROVE IT FUNCTIONALLY
# ----------------------------------------------------------------------------
# IMPORTANT:
# A .pt file SHA-256 is a byte-level serialization identity.  It is useful for
# archival integrity, but it is NOT by itself the scientific identity consumed
# by Block 7.  Block 7 consumed the standardized float32 T matrix and recorded
# its exact SHA1 digest (dtype + shape + bytes).  Therefore:
#
#   * exact checkpoint SHA is preferred and recorded;
#   * a SHA-mismatching candidate is NEVER accepted merely by metadata;
#   * a candidate is accepted only if, after full Block-1 -> saved frontend ->
#     saved CIACNet -> saved T scaler replay, ALL 1092 T rows reproduce the
#     frozen B7 T_input_digest byte-for-byte;
#   * the frozen B7 SAE must then reproduce authoritative T activations with
#     identical Top-K support before E activations are exported.
#
# This is a fail-closed functional-equivalence audit, not a relaxed digest test.
_expected_b6_pipeline_sha = str(_b6_manifest.get("pipeline_sha256", "")).strip()
if not _expected_b6_pipeline_sha:
    raise RuntimeError("Frozen Block-6 manifest does not record pipeline_sha256.")

_b6_override = globals().get("OLD_B6_PIPELINE_PT_OVERRIDE", None)
_candidate_paths = []
_candidate_notes = {}


def _add_candidate(p, note):
    if p in (None, ""):
        return
    p = Path(str(p)).expanduser().resolve()
    if p.is_file() and str(p) not in {str(x) for x in _candidate_paths}:
        _candidate_paths.append(p)
        _candidate_notes[str(p)] = str(note)


# A) Explicit user override.
if _b6_override not in (None, ""):
    _add_candidate(_b6_override, "explicit override")

# B) Immutable release copy, if the release actually contains the expected SHA.
_artifact_index_path = _release_dir / "artifact_index.csv"
if _artifact_index_path.is_file():
    try:
        _idx = pd.read_csv(_artifact_index_path)
        if {"release_relpath", "sha256"} <= set(_idx.columns):
            _rows = _idx[_idx["sha256"].astype(str).eq(_expected_b6_pipeline_sha)]
            for _r in _rows.itertuples(index=False):
                _add_candidate(
                    _release_dir / str(getattr(_r, "release_relpath")),
                    "exact SHA recorded in frozen artifact_index.csv",
                )
    except Exception:
        pass

# C) Any exact-SHA .pt file physically present in the release.
for _p in sorted(_release_dir.rglob("*.pt"), key=lambda p: str(p)):
    try:
        if _sha256_file(_p) == _expected_b6_pipeline_sha:
            _add_candidate(_p, "exact SHA found recursively inside frozen release")
    except Exception:
        pass

# D) Historical source path recorded by the frozen release.  This is allowed to
# enter the AUDIT even when its file SHA has changed.  It will NOT be accepted
# unless the full T embedding matrix exactly reproduces B7 T_input_digest.
_src_b6_manifest = str(
    (_release_manifest.get("manifest_source_paths", {}) or {}).get("B6", "")
).strip()
if _src_b6_manifest:
    _historical = (
        Path(_src_b6_manifest).expanduser().resolve().parent
        / "block6_shared_sessionT_pipeline.pt"
    )
    _add_candidate(_historical, "historical Block-6 source recorded by frozen release")

# E) Optional archive roots supplied by the user.  Search only the canonical
# filename to avoid hashing every model in Drive.
for _root in globals().get("OLD_B6_ARCHIVE_SEARCH_ROOTS", []) or []:
    try:
        _root = Path(str(_root)).expanduser().resolve()
        if _root.exists():
            for _p in _root.rglob("block6_shared_sessionT_pipeline.pt"):
                _add_candidate(_p, f"archive root: {_root}")
    except Exception:
        pass

if not _candidate_paths:
    raise RuntimeError(
        "No Block-6 pipeline checkpoint candidate could be located. Set "
        "OLD_B6_PIPELINE_PT_OVERRIDE to a candidate .pt file or provide "
        "OLD_B6_ARCHIVE_SEARCH_ROOTS."
    )

# Prefer exact byte-identical checkpoint if one exists; otherwise audit the
# historical source candidate.  Functional acceptance happens later via the
# exact B7 T_input_digest gate.
_candidate_rows = []
for _p in _candidate_paths:
    try:
        _sha = _sha256_file(_p)
    except Exception:
        _sha = ""
    _candidate_rows.append({
        "path": str(_p),
        "source": _candidate_notes.get(str(_p), ""),
        "sha256": _sha,
        "checkpoint_sha_exact": bool(_sha == _expected_b6_pipeline_sha),
    })

OLD_B6_CHECKPOINT_CANDIDATE_DF = pd.DataFrame(_candidate_rows)
OLD_B6_CHECKPOINT_CANDIDATE_DF = OLD_B6_CHECKPOINT_CANDIDATE_DF.sort_values(
    ["checkpoint_sha_exact", "path"], ascending=[False, True], kind="stable"
).reset_index(drop=True)

_b6_pipeline_path = Path(OLD_B6_CHECKPOINT_CANDIDATE_DF.iloc[0]["path"]).resolve()
_actual_b6_pipeline_sha = str(OLD_B6_CHECKPOINT_CANDIDATE_DF.iloc[0]["sha256"])
_b6_checkpoint_sha_exact = bool(
    OLD_B6_CHECKPOINT_CANDIDATE_DF.iloc[0]["checkpoint_sha_exact"]
)

print("=" * 132)
print("OLD BLOCK-6 CHECKPOINT RESOLUTION")
print("=" * 132)
print(OLD_B6_CHECKPOINT_CANDIDATE_DF.to_string(index=False))
print("-" * 132)
print("Selected candidate             :", _b6_pipeline_path)
print("Expected frozen file SHA-256   :", _expected_b6_pipeline_sha)
print("Selected candidate SHA-256     :", _actual_b6_pipeline_sha)
print("Byte-identical checkpoint      :", "YES" if _b6_checkpoint_sha_exact else "NO")
if not _b6_checkpoint_sha_exact:
    print("Scientific acceptance          : PENDING exact full-T B7 input digest replay")
print("=" * 132)

try:
    _b6_artifact = torch.load(
        str(_b6_pipeline_path), map_location="cpu", weights_only=False
    )
except TypeError:
    _b6_artifact = torch.load(str(_b6_pipeline_path), map_location="cpu")

if not isinstance(_b6_artifact, dict):
    raise RuntimeError("Block-6 checkpoint candidate has unsupported schema.")

for _k in (
    "state", "frontend", "n_model_ch", "model_option", "model_name",
    "embed_layer", "embed_dim", "model_window_s", "training_scope",
    "training_population", "competent_subjects", "block6_selection_sig",
    "probe_scaler_mean", "probe_scaler_scale",
):
    if _k not in _b6_artifact:
        raise RuntimeError(f"Block-6 checkpoint candidate lacks {_k!r}.")

# Metadata is necessary but not sufficient.  The exact full-T digest below is
# the decisive scientific gate.
if str(_b6_artifact["block6_selection_sig"]) != _expected_b6_sig:
    raise RuntimeError(
        "Block-6 candidate selection signature differs from the frozen lineage."
    )
if str(_b6_artifact["training_scope"]) != "session_T_only":
    raise RuntimeError("Block-6 candidate is not marked Session-T-only.")
if str(_b6_artifact["training_population"]) != "block5_competent_subjects_shared":
    raise RuntimeError("Block-6 candidate training-population identity mismatch.")
if int(_b6_artifact["model_option"]) != 1:
    raise RuntimeError("Old release requires the FBCSP+CIACNet branch (model_option=1).")
if str(_b6_artifact["model_name"]) != "ciacnet_fbcsp":
    raise RuntimeError(f"Unexpected old Block-6 model: {_b6_artifact['model_name']!r}.")
if str(_b6_artifact["embed_layer"]) != "concat_cb_tc" or int(_b6_artifact["embed_dim"]) != 96:
    raise RuntimeError("Old Block-6 embedding contract is not concat_cb_tc / D=96.")

_competent_subjects = np.asarray(
    _b6_artifact["competent_subjects"], dtype=np.int64
).reshape(-1)


# ----------------------------------------------------------------------------
# 2. LOAD + VERIFY AUTHORITATIVE BLOCK-1 EEG, THEN REBUILD EXACT T/E ROWS
# ----------------------------------------------------------------------------
# Old Block-1 manifests use `selection_signature`; later code sometimes uses
# `selection_sig`.  The authoritative lineage value is also recorded upstream
# in the frozen Block-7 manifest.  Resolve all of these and require agreement.
def _manifest_selection_sig(man: dict) -> str:
    for _k in ("selection_signature", "selection_sig"):
        _v = str((man or {}).get(_k, "")).strip()
        if _v:
            return _v
    return ""

_b1_sig_manifest = _manifest_selection_sig(_b1_manifest)
_b1_sig_from_b7 = str(
    (_b7_manifest.get("upstream", {}) or {}).get("block1_selection_sig", "")
).strip()
_expected_b1_sig = _b1_sig_from_b7 or _b1_sig_manifest
if not _expected_b1_sig:
    raise RuntimeError("Frozen lineage does not expose the authoritative Block-1 selection signature.")
if _b1_sig_manifest and _b1_sig_manifest != _expected_b1_sig:
    raise RuntimeError(
        "Frozen Block-1 manifest and Block-7 upstream lineage disagree on the Block-1 signature.\n"
        f"B1 manifest : {_b1_sig_manifest}\n"
        f"B7 upstream : {_b1_sig_from_b7}"
    )

_expected_b1_fp = str(_b1_manifest.get("fingerprint", "")).strip()
if not _expected_b1_fp:
    raise RuntimeError("Frozen Block-1 manifest does not contain its fingerprint.")

_b1_override = globals().get("OLD_B1_ARRAYS_NPZ_OVERRIDE", None)
_b1_candidates = []
_b1_candidate_notes = {}

def _add_b1_candidate(p, note):
    if p in (None, ""):
        return
    try:
        _p = Path(str(p)).expanduser().resolve()
    except Exception:
        return
    if _p.is_file() and str(_p) not in {str(x) for x in _b1_candidates}:
        _b1_candidates.append(_p)
        _b1_candidate_notes[str(_p)] = str(note)

# A) Explicit override.
_add_b1_candidate(_b1_override, "explicit override")

# B) Prefer a copy preserved inside the immutable frozen release.
if _artifact_index_path.is_file():
    try:
        _idx_b1 = pd.read_csv(_artifact_index_path)
        if "release_relpath" in _idx_b1.columns:
            _mask = _idx_b1["release_relpath"].astype(str).map(
                lambda s: Path(s).name == "block1_arrays.npz"
            )
            if "block" in _idx_b1.columns:
                _mask &= _idx_b1["block"].astype(str).str.upper().eq("B1")
            for _r in _idx_b1[_mask].itertuples(index=False):
                _add_b1_candidate(
                    _release_dir / str(_r.release_relpath),
                    "immutable frozen-release B1 artifact",
                )
    except Exception:
        pass

# C) Any block1_arrays.npz physically present inside RELEASE_DIR.
try:
    for _p in _release_dir.rglob("block1_arrays.npz"):
        _add_b1_candidate(_p, "frozen-release recursive discovery")
except Exception:
    pass

# D) Historical source recorded by the release.
_src_b1_manifest = str(
    (_release_manifest.get("manifest_source_paths", {}) or {}).get("B1", "")
).strip()
if _src_b1_manifest:
    _add_b1_candidate(
        Path(_src_b1_manifest).expanduser().resolve().parent / "block1_arrays.npz",
        "historical Block-1 source recorded by frozen release",
    )

if not _b1_candidates:
    raise FileNotFoundError(
        "No Block-1 arrays candidate was found. Set OLD_B1_ARRAYS_NPZ_OVERRIDE to an archived "
        "block1_arrays.npz from the old lineage."
    )

_b1_audit_rows = []
_b1_selected = None
_b1_loaded = None
for _p in _b1_candidates:
    _row = {
        "path": str(_p),
        "source": _b1_candidate_notes.get(str(_p), "candidate"),
        "selection_sig": "",
        "selection_sig_ok": False,
        "stored_fingerprint": "",
        "calculated_fingerprint": "",
        "fingerprint_ok": False,
        "status": "",
    }
    try:
        with np.load(_p, allow_pickle=False) as _z:
            _need = {
                "X", "y", "sid", "session", "run", "uid",
                "selection_sig", "fs", "fingerprint"
            }
            _miss = sorted(_need - set(_z.files))
            if _miss:
                raise RuntimeError("missing fields: " + ", ".join(_miss))
            _Xc = np.asarray(_z["X"], dtype=np.float32)
            _yc = np.asarray(_z["y"], dtype=np.int64).reshape(-1)
            _sidc = np.asarray(_z["sid"], dtype=np.int64).reshape(-1)
            _sesc = np.asarray(_z["session"]).astype(str).reshape(-1)
            _runc = np.asarray(_z["run"]).astype(str).reshape(-1)
            _uidc = np.asarray(_z["uid"]).astype(str).reshape(-1)
            _sigc = str(np.asarray(_z["selection_sig"]).item()).strip()
            _fsc = float(np.asarray(_z["fs"]).item())
            _fpc_stored = str(np.asarray(_z["fingerprint"]).item()).strip()

        _fpc_calc = _b1_fingerprint(_Xc, _yc, _sidc, _sesc, _runc, _uidc)
        _sig_ok = (_sigc == _expected_b1_sig)
        _fp_ok = (_fpc_stored == _expected_b1_fp and _fpc_calc == _expected_b1_fp)
        _row.update({
            "selection_sig": _sigc,
            "selection_sig_ok": bool(_sig_ok),
            "stored_fingerprint": _fpc_stored,
            "calculated_fingerprint": _fpc_calc,
            "fingerprint_ok": bool(_fp_ok),
            "status": "PASS" if (_sig_ok and _fp_ok) else "REJECT",
        })
        if _sig_ok and _fp_ok and _b1_selected is None:
            _b1_selected = _p
            _b1_loaded = (_Xc, _yc, _sidc, _sesc, _runc, _uidc, _fsc)
    except Exception as _exc:
        _row["status"] = f"ERROR: {type(_exc).__name__}: {_exc}"
    _b1_audit_rows.append(_row)

_B1_AUDIT_DF = pd.DataFrame(_b1_audit_rows)
print("\n" + "=" * 132)
print("OLD BLOCK-1 AUTHORITATIVE ARCHIVE RESOLUTION")
print("=" * 132)
print("Expected B1 selection signature :", _expected_b1_sig)
print("Expected B1 fingerprint         :", _expected_b1_fp)
print(_B1_AUDIT_DF[[
    "status", "selection_sig_ok", "fingerprint_ok", "source", "path"
]].to_string(index=False))
print("=" * 132)

if _b1_selected is None or _b1_loaded is None:
    raise RuntimeError(
        "No Block-1 archive reproduces BOTH the frozen Block-1 selection signature and fingerprint. "
        "Do not relax these checks. Recover an archived Block-1 arrays file from the old lineage."
    )

_b1_arrays_path = _b1_selected
_X1, _y1, _sid1, _ses1, _run1, _uid1, _fs = _b1_loaded
print("Selected authoritative B1 archive:", _b1_arrays_path)
print("Block-1 signature/fingerprint   : PASS")

if _X1.ndim != 4 or _X1.shape[1] != 1:
    raise RuntimeError(f"Old Block-1 X must be (N,1,C,T); got {_X1.shape}.")
if not all(len(v) == len(_X1) for v in (_y1, _sid1, _ses1, _run1, _uid1)):
    raise RuntimeError("Old Block-1 EEG/identity arrays are not row-aligned.")

# Authoritative T identity comes from the frozen full Block-7 activation artifact.
with np.load(_b7_acts_path, allow_pickle=False) as _z:
    _need_b7 = {
        "act_T", "T_uid", "T_y", "T_sid", "T_run", "T_global_idx",
        "selection_sig", "n_latents",
    }
    _miss = sorted(_need_b7 - set(_z.files))
    if _miss:
        raise RuntimeError("Frozen full B7 activation artifact lacks: " + ", ".join(_miss))
    _F_T_authoritative = np.asarray(_z["act_T"], dtype=np.float32)
    _T_uid_ref = np.asarray(_z["T_uid"]).astype(str).reshape(-1)
    _T_y_ref = np.asarray(_z["T_y"], dtype=np.int64).reshape(-1)
    _T_sid_ref = np.asarray(_z["T_sid"], dtype=np.int64).reshape(-1)
    _T_run_ref = np.asarray(_z["T_run"]).astype(str).reshape(-1)
    _T_idx_ref = np.asarray(_z["T_global_idx"], dtype=np.int64).reshape(-1)
    _b7_npz_sig = str(np.asarray(_z["selection_sig"]).item())
    _n_latents = int(np.asarray(_z["n_latents"]).item())

if _b7_npz_sig != _expected_b7_sig:
    raise RuntimeError("Frozen full B7 activation artifact selection signature mismatch.")
if _F_T_authoritative.shape != (len(_T_idx_ref), _n_latents):
    raise RuntimeError("Frozen authoritative T activation matrix has invalid shape.")

# Re-derive the old Block-5 competent T/E row sets from immutable B1 identity.
_T_idx_derived = np.flatnonzero(
    np.isin(_sid1, _competent_subjects) & (_ses1 == "T")
).astype(np.int64)
_E_idx = np.flatnonzero(
    np.isin(_sid1, _competent_subjects) & (_ses1 == "E")
).astype(np.int64)

if not np.array_equal(_T_idx_derived, _T_idx_ref):
    raise RuntimeError(
        "Re-derived old competent Session-T indices do not equal the frozen Block-7 T identity."
    )
if not np.array_equal(_uid1[_T_idx_ref], _T_uid_ref):
    raise RuntimeError("Old frozen T UID alignment failed against authoritative Block-1 rows.")
if not np.array_equal(_y1[_T_idx_ref], _T_y_ref):
    raise RuntimeError("Old frozen T label alignment failed.")
if not np.array_equal(_sid1[_T_idx_ref], _T_sid_ref):
    raise RuntimeError("Old frozen T subject alignment failed.")
if not np.array_equal(_run1[_T_idx_ref], _T_run_ref):
    raise RuntimeError("Old frozen T run alignment failed.")
if len(_E_idx) == 0 or not np.all(_ses1[_E_idx] == "E"):
    raise RuntimeError("Could not reconstruct the old competent Session-E row set.")

# If the historical B6 embedding NPZ still exists, use it only as an ID audit.
# Its numeric coordinates are deliberately NOT trusted here.
_b6_npz_candidate = _b6_pipeline_path.parent / "block6_shared_embeddings.npz"
if _b6_npz_candidate.is_file():
    try:
        with np.load(_b6_npz_candidate, allow_pickle=False) as _z:
            if {"E_idx", "E_uid", "E_y", "E_sid", "E_run"} <= set(_z.files):
                if not np.array_equal(np.asarray(_z["E_idx"], np.int64), _E_idx):
                    raise RuntimeError("Historical B6 NPZ E_idx disagrees with re-derived E identity.")
                if not np.array_equal(np.asarray(_z["E_uid"]).astype(str), _uid1[_E_idx]):
                    raise RuntimeError("Historical B6 NPZ E_uid disagrees with re-derived E identity.")
                if not np.array_equal(np.asarray(_z["E_y"], np.int64), _y1[_E_idx]):
                    raise RuntimeError("Historical B6 NPZ E_y disagrees with re-derived E identity.")
                if not np.array_equal(np.asarray(_z["E_sid"], np.int64), _sid1[_E_idx]):
                    raise RuntimeError("Historical B6 NPZ E_sid disagrees with re-derived E identity.")
                if not np.array_equal(np.asarray(_z["E_run"]).astype(str), _run1[_E_idx]):
                    raise RuntimeError("Historical B6 NPZ E_run disagrees with re-derived E identity.")
    except Exception as exc:
        raise RuntimeError(f"Historical B6 identity audit failed: {exc}") from exc


# ----------------------------------------------------------------------------
# 3. EXACT ORIGINAL CIACNET ARCHITECTURE (BLOCK 2 v5.2 / BLOCK 6 v1.3)
# ----------------------------------------------------------------------------
class ImprovedChannelAttention(nn.Module):
    def __init__(self, channels, reduction=8):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        bottleneck = max(1, channels // reduction)
        self.mlp = nn.Sequential(
            nn.Flatten(),
            nn.Linear(channels, bottleneck, bias=False),
            nn.ReLU(),
            nn.Linear(bottleneck, channels, bias=False),
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        B, C = x.shape[:2]
        avg = self.mlp(self.avg_pool(x))
        mx = self.mlp(self.max_pool(x))
        return x * self.sigmoid((avg + mx).view(B, C, 1, 1))


class ImprovedSpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super().__init__()
        p = kernel_size // 2
        self.conv_avg = nn.Conv2d(1, 1, kernel_size, padding=p, bias=False)
        self.conv_max = nn.Conv2d(1, 1, kernel_size, padding=p, bias=False)
        self.fuse = nn.Conv2d(2, 1, kernel_size, padding=p, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg = self.conv_avg(x.mean(dim=1, keepdim=True))
        mx = self.conv_max(x.max(dim=1, keepdim=True).values)
        return x * self.sigmoid(self.fuse(torch.cat([avg, mx], dim=1)))


class ImprovedCBAM(nn.Module):
    def __init__(self, channels, reduction=8, spatial_kernel=7):
        super().__init__()
        self.ca = ImprovedChannelAttention(channels, reduction)
        self.sa = ImprovedSpatialAttention(spatial_kernel)

    def forward(self, x):
        return self.sa(self.ca(x))


class TCNBlock(nn.Module):
    def __init__(self, in_ch, out_ch, kernel_size=3, dilation=1, dropout=0.2):
        super().__init__()
        pad = (kernel_size - 1) * dilation
        self.conv1 = nn.Conv1d(in_ch, out_ch, kernel_size, dilation=dilation, padding=pad)
        self.conv2 = nn.Conv1d(out_ch, out_ch, kernel_size, dilation=dilation, padding=pad)
        self.bn1 = nn.BatchNorm1d(out_ch)
        self.bn2 = nn.BatchNorm1d(out_ch)
        self.act = nn.ELU()
        self.drop = nn.Dropout(dropout)
        self.chomp_s = pad
        self.res = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity()

    @staticmethod
    def _chomp(x, c):
        return x[:, :, :-c].contiguous() if c > 0 else x

    def forward(self, x):
        h = self._chomp(self.drop(self.act(self.bn1(self.conv1(x)))), self.chomp_s)
        h = self._chomp(self.drop(self.act(self.bn2(self.conv2(h)))), self.chomp_s)
        return self.act(h + self.res(x))


class TCN(nn.Module):
    def __init__(self, in_ch, n_filters=32, levels=4, kernel_size=4, dropout=0.2):
        super().__init__()
        self.net = nn.Sequential(*[
            TCNBlock(
                in_ch if i == 0 else n_filters,
                n_filters,
                kernel_size,
                2 ** i,
                dropout,
            )
            for i in range(levels)
        ])

    def forward(self, x):
        return self.net(x)


class CVBlock(nn.Module):
    def __init__(self, F1=16, D=2, n_ch=64, dropout=0.5):
        super().__init__()
        F2 = F1 * D

        def branch(k_temporal):
            return nn.Sequential(
                nn.Conv2d(1, F1, (1, k_temporal), padding="same", bias=False),
                nn.BatchNorm2d(F1), nn.ELU(),
                nn.Conv2d(F1, F2, (n_ch, 1), groups=F1, bias=False),
                nn.BatchNorm2d(F2), nn.ELU(),
                nn.AvgPool2d((1, 4)), nn.Dropout(dropout),
                nn.Conv2d(F2, F2, (1, 16), padding="same", bias=False),
                nn.BatchNorm2d(F2), nn.ELU(),
                nn.AvgPool2d((1, 8)), nn.Dropout(dropout),
            )

        self.branch_a = branch(32)
        self.branch_b = branch(64)

    def forward(self, x):
        a = self.branch_a(x)
        b = self.branch_b(x)
        T = min(a.shape[-1], b.shape[-1])
        return torch.cat([a[..., :T], b[..., :T]], dim=1)


class CIACNet(nn.Module):
    VALID_LAYERS = ("cv_g", "cb_g", "tc_g", "concat_cb_tc", "feat_current")

    def __init__(
        self, n_classes=2, n_ch=24, F1=16, D=2, dropout=0.5,
        tcn_filters=32, tcn_levels=4, tcn_kernel=4,
    ):
        super().__init__()
        F2 = F1 * D
        n_cv_ch = 2 * F2
        self.cv = CVBlock(F1, D, n_ch, dropout)
        self.cbam = ImprovedCBAM(n_cv_ch, reduction=4)
        self.tcn = TCN(n_cv_ch, tcn_filters, tcn_levels, tcn_kernel, dropout)
        self.gap = nn.AdaptiveAvgPool1d(1)
        self.drop = nn.Dropout(dropout)
        self.fc = nn.Linear(n_cv_ch + n_cv_ch + tcn_filters, n_classes)

    def layer_taps(self, x):
        cv_out = self.cv(x)
        cb_out = self.cbam(cv_out)
        cv_sq = cv_out.squeeze(2)
        cb_sq = cb_out.squeeze(2)
        tcn_out = self.tcn(cb_sq)
        cv_g = self.gap(cv_sq).squeeze(-1)
        cb_g = self.gap(cb_sq).squeeze(-1)
        tc_g = self.gap(tcn_out).squeeze(-1)
        return OrderedDict(
            cv_g=cv_g,
            cb_g=cb_g,
            tc_g=tc_g,
            concat_cb_tc=torch.cat([cb_g, tc_g], dim=1),
            feat_current=torch.cat([cv_g, cb_g, tc_g], dim=1),
        )

    def embed(self, x, layer="concat_cb_tc"):
        if layer not in self.VALID_LAYERS:
            raise ValueError(f"Unknown CIACNet layer {layer!r}; use {self.VALID_LAYERS}.")
        return self.layer_taps(x)[layer]

    def forward(self, x):
        feat = self.layer_taps(x)["feat_current"]
        return self.fc(self.drop(feat)), feat


# ----------------------------------------------------------------------------
# 4. EXACT SAVED FBCSP FRONTEND APPLICATION
# ----------------------------------------------------------------------------
def _resolve_crop_indices(n_time: int):
    epoch_tmin = float(_b1_manifest.get("epoch_tmin", -2.0))
    model_window = list(_b6_artifact["model_window_s"])
    if len(model_window) != 2:
        raise RuntimeError("Old Block-6 checkpoint has invalid model_window_s.")
    model_tmin, model_tmax = map(float, model_window)
    i0 = int(round((model_tmin - epoch_tmin) * _fs))
    i1 = int(round((model_tmax - epoch_tmin) * _fs))
    i0 = max(0, i0)
    i1 = min(int(n_time), i1)
    if i1 <= i0:
        raise RuntimeError("Recovered old Block-2 model window is empty.")
    return i0, i1, epoch_tmin, model_tmin, model_tmax


def _apply_saved_fbcsp_frontend(X_trials: np.ndarray) -> np.ndarray:
    """Exact old _b2_apply_frontend path for saved FBCSP state."""
    X_trials = np.asarray(X_trials, dtype=np.float32)
    if X_trials.ndim != 4 or X_trials.shape[1] != 1:
        raise RuntimeError(f"Expected (N,1,C,T) old EEG, got {X_trials.shape}.")

    i0, i1, _, _, _ = _resolve_crop_indices(X_trials.shape[-1])
    Xc = np.ascontiguousarray(X_trials[..., i0:i1], dtype=np.float32)

    frontend = _b6_artifact["frontend"]
    if not isinstance(frontend, dict):
        raise RuntimeError("Saved old Block-6 frontend is not a plain dictionary.")
    if str(frontend.get("kind", "")) != "fbcsp":
        raise RuntimeError("Saved old Block-6 frontend is not FBCSP.")

    norm = frontend.get("norm", {}) or {}
    mu = float(norm["mu"])
    sd = float(norm["sd"])
    if not np.isfinite(mu) or not np.isfinite(sd) or sd <= 0:
        raise RuntimeError("Saved old Block-6 frontend normalization is invalid.")

    # Exact old _b2_apply_scalar_norm behavior.
    Xn = ((Xc - mu) / sd).astype(np.float32)
    X3 = Xn[:, 0]

    fstate = frontend.get("fbcsp_state", None)
    if not isinstance(fstate, dict):
        raise RuntimeError("Saved old Block-6 frontend lacks fbcsp_state.")

    bands = OrderedDict(fstate["bands"])
    filters = fstate["filters"]
    outs = []
    for name, (lo, hi) in bands.items():
        if str(name) not in filters:
            raise RuntimeError(f"Saved FBCSP filter matrix missing band {name!r}.")
        sos = butter(5, [float(lo), float(hi)], btype="bandpass", fs=float(fstate["fs"]), output="sos")
        Xb = sosfiltfilt(sos, np.asarray(X3, dtype=np.float32), axis=-1).astype(np.float32)
        W = np.asarray(filters[str(name)], dtype=np.float32)
        outs.append(np.einsum("fc,nct->nft", W, Xb, optimize=True).astype(np.float32))

    Xm = np.concatenate(outs, axis=1)[:, None, :, :]
    if Xm.shape[2] != int(_b6_artifact["n_model_ch"]):
        raise RuntimeError(
            f"Recovered FBCSP width {Xm.shape[2]} != saved n_model_ch={_b6_artifact['n_model_ch']}."
        )
    return Xm.astype(np.float32, copy=False)


def _build_old_ciacnet(device_name: str) -> CIACNet:
    # These are the exact old Block-2 v5.2 CIACNet settings that produced this run.
    model = CIACNet(
        n_classes=2,
        n_ch=int(_b6_artifact["n_model_ch"]),
        F1=16,
        D=2,
        dropout=0.5,
        tcn_filters=32,
        tcn_levels=4,
        tcn_kernel=4,
    ).to(torch.device(device_name))
    model.load_state_dict(_b6_artifact["state"], strict=True)
    model.eval()
    for p in model.parameters():
        p.requires_grad_(False)
    return model


@torch.no_grad()
def _extract_raw_embedding(Xm: np.ndarray, device_name: str) -> np.ndarray:
    model = _build_old_ciacnet(device_name)
    outs = []
    dev = torch.device(device_name)
    for start in range(0, len(Xm), OLD_B6_INFER_BATCH):
        xb = torch.from_numpy(
            np.asarray(Xm[start:start + OLD_B6_INFER_BATCH], dtype=np.float32)
        ).to(dev)
        z = model.embed(xb, layer="concat_cb_tc")
        outs.append(z.detach().cpu().numpy())
    del model
    if str(device_name).startswith("cuda") and torch.cuda.is_available():
        torch.cuda.empty_cache()
    Z = np.concatenate(outs, axis=0).astype(np.float32)
    if Z.shape != (len(Xm), 96):
        raise RuntimeError(f"Recovered old raw embedding shape {Z.shape} != ({len(Xm)},96).")
    return Z


def _standardize_old_b6(Z_raw: np.ndarray) -> np.ndarray:
    mean = np.asarray(_b6_artifact["probe_scaler_mean"], dtype=np.float64).reshape(-1)
    scale = np.asarray(_b6_artifact["probe_scaler_scale"], dtype=np.float64).reshape(-1)
    if mean.shape != (96,) or scale.shape != (96,) or np.any(scale <= 0):
        raise RuntimeError("Old Block-6 saved scaler has invalid geometry/scale.")
    return ((Z_raw.astype(np.float64) - mean) / scale).astype(np.float32)


# Precompute saved frontend outputs once; neural backend is the only backend-dependent part.
_Xm_T = _apply_saved_fbcsp_frontend(_X1[_T_idx_ref])
_Xm_E = _apply_saved_fbcsp_frontend(_X1[_E_idx])

_original_b6_device = str(
    (_b6_manifest.get("environment", {}) or {}).get("device", "cuda")
).strip().lower()


def _device_available(name: str) -> bool:
    name = str(name).lower()
    if name.startswith("cuda"):
        return bool(torch.cuda.is_available())
    return name == "cpu"

_b6_devices = []
if _original_b6_device and _device_available(_original_b6_device):
    _b6_devices.append(_original_b6_device)
for _d in ("cuda", "cpu"):
    if _device_available(_d) and _d not in _b6_devices:
        _b6_devices.append(_d)
if not _b6_devices:
    _b6_devices = ["cpu"]

_b6_audit_rows = []
_accepted_b6_device = None
_old_emb_T = None
_old_emb_E = None
_old_raw_T = None
_old_raw_E = None

for _dev in _b6_devices:
    try:
        _raw_T = _extract_raw_embedding(_Xm_T, _dev)
        _emb_T = _standardize_old_b6(_raw_T)
        _digest = _b7_digest_numeric(_emb_T)
        _exact = (_digest == _expected_b7_input_digest)
        _b6_audit_rows.append({
            "device": _dev,
            "original_recorded_device": _original_b6_device,
            "batch_size": OLD_B6_INFER_BATCH,
            "T_input_digest": _digest,
            "expected_T_input_digest": _expected_b7_input_digest,
            "exact_digest_match": bool(_exact),
            "status": "PASS_EXACT" if _exact else "FAIL_DIGEST",
        })
        if _exact:
            # Important: compute E with the same accepted backend and exact saved transform.
            _raw_E = _extract_raw_embedding(_Xm_E, _dev)
            _emb_E = _standardize_old_b6(_raw_E)
            _accepted_b6_device = _dev
            _old_raw_T, _old_raw_E = _raw_T, _raw_E
            _old_emb_T, _old_emb_E = _emb_T, _emb_E
            break
    except Exception as exc:
        _b6_audit_rows.append({
            "device": _dev,
            "original_recorded_device": _original_b6_device,
            "batch_size": OLD_B6_INFER_BATCH,
            "T_input_digest": "",
            "expected_T_input_digest": _expected_b7_input_digest,
            "exact_digest_match": False,
            "status": f"ERROR: {type(exc).__name__}: {exc}",
        })

OLD_B6_REVERSE_ENGINEERING_AUDIT_DF = pd.DataFrame(_b6_audit_rows)

if _accepted_b6_device is None:
    print("\n" + "=" * 132)
    print("OLD BLOCK-6 EXACT TRANSFORM RECOVERY — BLOCKED")
    print("=" * 132)
    print(OLD_B6_REVERSE_ENGINEERING_AUDIT_DF.to_string(index=False))
    print("=" * 132)
    raise RuntimeError(
        "No available Block-6 candidate reproduced the frozen Block-7 Session-T input "
        "digest exactly on any available backend.\n"
        "Do NOT use its Session-E embeddings with the old feature dictionary.\n"
        "If the original run used CUDA, rerun this recovery on a compatible GPU runtime."
    )


# ----------------------------------------------------------------------------
# 5. REPLAY THE ORIGINAL FROZEN BLOCK-7 SAE; T MUST REPRODUCE BEFORE E IS USED
# ----------------------------------------------------------------------------
try:
    _b7_payload = torch.load(
        str(_b7_checkpoint_path), map_location="cpu", weights_only=False
    )
except TypeError:
    _b7_payload = torch.load(str(_b7_checkpoint_path), map_location="cpu")

if not isinstance(_b7_payload, dict) or "state_dict" not in _b7_payload or "sae_config" not in _b7_payload:
    raise RuntimeError("Old frozen Block-7 checkpoint has unsupported schema.")
if str(_b7_payload.get("selection_sig", "")) != _expected_b7_sig:
    raise RuntimeError("Old frozen Block-7 checkpoint selection signature mismatch.")
if str(_b7_payload.get("block6_selection_sig", "")) != _expected_b6_sig:
    raise RuntimeError("Old frozen Block-7 checkpoint is not bound to the recovered Block-6 lineage.")

_b7_ser = _b7_manifest.get("serialization_audit", {}) or {}
_b7_cfg = _b7_manifest.get("config", {}) or {}
_b7_atol = float(_b7_ser.get("atol", 1e-5))
_b7_rtol = float(_b7_ser.get("rtol", 1e-5))
_b7_batch = int(_b7_cfg.get("infer_batch", _b7_ser.get("batch_geometry", 512)))
if _b7_batch < 1:
    raise RuntimeError("Frozen Block-7 inference batch geometry is invalid.")

_original_b7_device = str(
    (_b7_manifest.get("environment", {}) or {}).get("device", _accepted_b6_device)
).strip().lower()


def _frozen_sae_activations(X_emb: np.ndarray, device_name: str) -> np.ndarray:
    X_emb = np.asarray(X_emb, dtype=np.float32)
    cfg = _b7_payload["sae_config"]
    d_model = int(cfg["d_model"])
    n_lat = int(cfg["n_latents"])
    k_use = int(min(int(cfg["k"]), n_lat))
    if X_emb.ndim != 2 or X_emb.shape[1] != d_model:
        raise RuntimeError(f"Old frozen SAE expects (N,{d_model}), got {X_emb.shape}.")

    state = _b7_payload["state_dict"]
    for key in ("b_pre", "encoder.weight", "encoder.bias"):
        if key not in state:
            raise RuntimeError(f"Old frozen SAE state_dict lacks {key!r}.")

    dev = torch.device(device_name)
    b_pre = state["b_pre"].detach().to(device=dev, dtype=torch.float32)
    enc_w = state["encoder.weight"].detach().to(device=dev, dtype=torch.float32)
    enc_b = state["encoder.bias"].detach().to(device=dev, dtype=torch.float32)

    out = []
    with torch.no_grad():
        for start in range(0, len(X_emb), _b7_batch):
            xb = torch.from_numpy(X_emb[start:start + _b7_batch]).to(
                device=dev, dtype=torch.float32
            )
            pre = torch.nn.functional.linear(xb - b_pre, enc_w, enc_b)
            positive = torch.relu(pre)
            vals, idx = torch.topk(positive, k=k_use, dim=1)
            sparse = torch.zeros_like(positive)
            sparse.scatter_(1, idx, vals)
            out.append(sparse.detach().cpu().numpy().astype(np.float32))
    return np.concatenate(out, axis=0) if out else np.empty((0, n_lat), np.float32)


_b7_devices = []
if _original_b7_device and _device_available(_original_b7_device):
    _b7_devices.append(_original_b7_device)
if _accepted_b6_device not in _b7_devices and _device_available(_accepted_b6_device):
    _b7_devices.append(_accepted_b6_device)
for _d in ("cuda", "cpu"):
    if _device_available(_d) and _d not in _b7_devices:
        _b7_devices.append(_d)
if not _b7_devices:
    _b7_devices = ["cpu"]

_b7_audit_rows = []
_accepted_b7_device = None
_F_E = None
for _dev in _b7_devices:
    try:
        _F_T_replay = _frozen_sae_activations(_old_emb_T, _dev)
        _same_shape = _F_T_replay.shape == _F_T_authoritative.shape
        if _same_shape:
            delta = _F_T_replay.astype(np.float64) - _F_T_authoritative.astype(np.float64)
            maxdiff = float(np.max(np.abs(delta))) if delta.size else 0.0
            meandiff = float(np.mean(np.abs(delta))) if delta.size else 0.0
            support_exact = float(np.mean(
                np.all((_F_T_replay > 0) == (_F_T_authoritative > 0), axis=1)
            ))
            allclose = bool(np.allclose(
                _F_T_replay, _F_T_authoritative, atol=_b7_atol, rtol=_b7_rtol
            ))
        else:
            maxdiff, meandiff, support_exact, allclose = np.inf, np.inf, 0.0, False

        pass_replay = bool(allclose and support_exact == 1.0)
        _b7_audit_rows.append({
            "device": _dev,
            "original_recorded_device": _original_b7_device,
            "batch_size": _b7_batch,
            "T_activation_allclose": allclose,
            "T_support_exact_fraction": support_exact,
            "T_max_abs_diff": maxdiff,
            "T_mean_abs_diff": meandiff,
            "status": "PASS" if pass_replay else "FAIL",
        })
        if pass_replay:
            _F_E = _frozen_sae_activations(_old_emb_E, _dev)
            _accepted_b7_device = _dev
            break
    except Exception as exc:
        _b7_audit_rows.append({
            "device": _dev,
            "original_recorded_device": _original_b7_device,
            "batch_size": _b7_batch,
            "T_activation_allclose": False,
            "T_support_exact_fraction": np.nan,
            "T_max_abs_diff": np.nan,
            "T_mean_abs_diff": np.nan,
            "status": f"ERROR: {type(exc).__name__}: {exc}",
        })

OLD_B7_REPLAY_AUDIT_DF = pd.DataFrame(_b7_audit_rows)
if _accepted_b7_device is None:
    print("\n" + "=" * 132)
    print("OLD BLOCK-7 FROZEN SAE REPLAY — BLOCKED")
    print("=" * 132)
    print(OLD_B7_REPLAY_AUDIT_DF.to_string(index=False))
    print("=" * 132)
    raise RuntimeError(
        "Recovered exact Block-6 coordinates were found, but frozen Block-7 replay did not "
        "reproduce the authoritative Session-T activations with exact Top-K support. "
        "Session-E use remains blocked."
    )

if _F_E.shape != (len(_E_idx), _n_latents):
    raise RuntimeError(f"Recovered old Session-E activation shape {_F_E.shape} is invalid.")
if not np.isfinite(_F_E).all() or np.any(_F_E < -1e-8):
    raise RuntimeError("Recovered old Session-E activations contain invalid values.")


# ----------------------------------------------------------------------------
# 6. EXPORT THE ORIGINAL FOUR RETAINED FEATURES ON SESSION E
# ----------------------------------------------------------------------------
with np.load(_identity_path, allow_pickle=False) as _z:
    OLD_FINAL_FEATURE_INDICES = np.asarray(
        _z["final_feature_indices"], dtype=np.int64
    ).reshape(-1)
    OLD_FINAL_FEATURE_IDS = np.asarray(_z["final_feature_ids"]).astype(str).reshape(-1)

_expected_old_ids = ["F0003", "F0020", "F0070", "F0078"]
_expected_old_idx = [3, 20, 70, 78]
if OLD_FINAL_FEATURE_IDS.tolist() != _expected_old_ids:
    raise RuntimeError(
        f"This recovery was requested for {_expected_old_ids}, but frozen release contains "
        f"{OLD_FINAL_FEATURE_IDS.tolist()}."
    )
if OLD_FINAL_FEATURE_INDICES.tolist() != _expected_old_idx:
    raise RuntimeError("Old final feature indices are not [3,20,70,78].")

OLD_B6_EMB_T_RECOVERED = _old_emb_T.astype(np.float32)
OLD_B6_EMB_E_RECOVERED = _old_emb_E.astype(np.float32)
OLD_B6_EMB_T_RAW_RECOVERED = _old_raw_T.astype(np.float32)
OLD_B6_EMB_E_RAW_RECOVERED = _old_raw_E.astype(np.float32)
OLD_B7_ACT_E_RECOVERED = _F_E.astype(np.float32)
OLD_FINAL4_ACT_E = OLD_B7_ACT_E_RECOVERED[:, OLD_FINAL_FEATURE_INDICES].copy()

OLD_E_GLOBAL_IDX = _E_idx.copy()
OLD_E_UID = _uid1[_E_idx].copy()
OLD_E_Y = _y1[_E_idx].copy()
OLD_E_SID = _sid1[_E_idx].copy()
OLD_E_RUN = _run1[_E_idx].copy()

OLD_RECOVERY_STATUS = (
    "PASS_BYTE_IDENTICAL_CHECKPOINT"
    if _b6_checkpoint_sha_exact
    else "PASS_FUNCTIONALLY_EXACT_T_REPLAY"
)
OLD_RECOVERY_PROVENANCE = {
    "status": OLD_RECOVERY_STATUS,
    "release_dir": str(_release_dir),
    "block6_selection_sig": _expected_b6_sig,
    "block7_selection_sig": _expected_b7_sig,
    "block6_pipeline_path": str(_b6_pipeline_path),
    "block6_pipeline_sha256_observed": _actual_b6_pipeline_sha,
    "block6_pipeline_sha256_expected": _expected_b6_pipeline_sha,
    "block6_checkpoint_sha_exact": bool(_b6_checkpoint_sha_exact),
    "block6_device": _accepted_b6_device,
    "block6_batch_size": OLD_B6_INFER_BATCH,
    "block7_device": _accepted_b7_device,
    "block7_batch_size": _b7_batch,
    "block7_T_input_digest": _b7_digest_numeric(OLD_B6_EMB_T_RECOVERED),
    "expected_block7_T_input_digest": _expected_b7_input_digest,
    "n_T": int(len(_T_idx_ref)),
    "n_E": int(len(_E_idx)),
    "final_feature_ids": OLD_FINAL_FEATURE_IDS.tolist(),
    "final_feature_indices": OLD_FINAL_FEATURE_INDICES.tolist(),
    "session_E_used_for_training": False,
    "T_E_pooled": False,
}

OLD_RECOVERY_NPZ = ""
OLD_RECOVERY_JSON = ""
if OLD_SAVE_RECOVERY:
    _out_dir = (
        _release_dir.parent.parent
        / "block12_old_release_exact_E_recovery"
        / str(_release_manifest.get("release_id", "release_v1"))
    ).resolve()
    _out_dir.mkdir(parents=True, exist_ok=True)
    _npz_path = _out_dir / "old_frozen_dictionary_sessionE_activations.npz"
    _json_path = _out_dir / "old_frozen_dictionary_sessionE_provenance.json"

    _tmp = str(_npz_path) + ".tmp"
    with open(_tmp, "wb") as f:
        np.savez_compressed(
            f,
            E_global_idx=OLD_E_GLOBAL_IDX.astype(np.int64),
            E_uid=OLD_E_UID.astype("<U192"),
            E_y=OLD_E_Y.astype(np.int64),
            E_sid=OLD_E_SID.astype(np.int64),
            E_run=OLD_E_RUN.astype("<U128"),
            emb_E=OLD_B6_EMB_E_RECOVERED.astype(np.float32),
            act_E=OLD_B7_ACT_E_RECOVERED.astype(np.float32),
            final_feature_ids=OLD_FINAL_FEATURE_IDS.astype("<U16"),
            final_feature_indices=OLD_FINAL_FEATURE_INDICES.astype(np.int64),
            final4_act_E=OLD_FINAL4_ACT_E.astype(np.float32),
            block6_selection_sig=np.asarray(_expected_b6_sig),
            block7_selection_sig=np.asarray(_expected_b7_sig),
            block7_T_input_digest=np.asarray(_b7_digest_numeric(OLD_B6_EMB_T_RECOVERED)),
            recovery_status=np.asarray(OLD_RECOVERY_STATUS),
        )
        f.flush(); os.fsync(f.fileno())
    os.replace(_tmp, _npz_path)

    _tmpj = str(_json_path) + ".tmp"
    with open(_tmpj, "w", encoding="utf-8") as f:
        json.dump(OLD_RECOVERY_PROVENANCE, f, indent=2)
        f.flush(); os.fsync(f.fileno())
    os.replace(_tmpj, _json_path)

    OLD_RECOVERY_NPZ = str(_npz_path)
    OLD_RECOVERY_JSON = str(_json_path)


print("\n" + "=" * 132)
print("OLD FROZEN RELEASE — FUNCTIONALLY VERIFIED BLOCK-6 + AUTHORITATIVE B1 + SESSION-E SAE RECOVERY: PASS")
print("=" * 132)
print(f"Release                         : {_release_manifest.get('release_id', '')}")
print(f"Block-6 sig                     : {_expected_b6_sig}")
print(f"Block-7 sig                     : {_expected_b7_sig}")
print(f"Expected B6 file SHA            : {_expected_b6_pipeline_sha}")
print(f"Observed B6 file SHA            : {_actual_b6_pipeline_sha}")
print(f"Byte-identical B6 checkpoint    : {'YES' if _b6_checkpoint_sha_exact else 'NO'}")
print(f"Recovered B6 device / batch     : {_accepted_b6_device} / {OLD_B6_INFER_BATCH}")
print(f"Exact full-T B7 input digest    : PASS")
print(f"Frozen B7 T activation replay   : PASS on {_accepted_b7_device}, batch={_b7_batch}")
print(f"Recovered E embeddings          : {OLD_B6_EMB_E_RECOVERED.shape}")
print(f"Recovered E all-latent acts     : {OLD_B7_ACT_E_RECOVERED.shape}")
print(f"Recovered old four E acts       : {OLD_FINAL4_ACT_E.shape}")
print(f"Old feature IDs                 : {OLD_FINAL_FEATURE_IDS.tolist()}")
print(f"Old feature indices             : {OLD_FINAL_FEATURE_INDICES.tolist()}")
print("Session E used for training     : NO")
print("T+E pooled                      : NO")
if OLD_RECOVERY_NPZ:
    print(f"Saved recovery NPZ              : {OLD_RECOVERY_NPZ}")
    print(f"Saved provenance JSON           : {OLD_RECOVERY_JSON}")
print("-" * 132)
print("Exports ready for old-feature Session-E analysis:")
print("  OLD_B6_EMB_E_RECOVERED")
print("  OLD_B7_ACT_E_RECOVERED          # E x 96, SAME old frozen dictionary")
print("  OLD_FINAL4_ACT_E                # E x 4 for F0003/F0020/F0070/F0078")
print("  OLD_E_GLOBAL_IDX, OLD_E_UID, OLD_E_Y, OLD_E_SID, OLD_E_RUN")
print("  OLD_B6_REVERSE_ENGINEERING_AUDIT_DF, OLD_B7_REPLAY_AUDIT_DF")
print("=" * 132)
