#!/usr/bin/env python3
"""Single entry point for REAL BCI-IV-2a and/or BCI-IV-2b downloads and reports."""
import argparse,subprocess,sys
from pathlib import Path
from sae_eeg.real_data import acquire

def call(*args):
    print('RUN:', ' '.join(map(str,args)),flush=True)
    subprocess.run([sys.executable,*map(str,args)],check=True)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--dataset',choices=['iv2a','iv2b','both'],default='both')
    p.add_argument('--subjects',type=int,nargs='*',help='Default: all nine subjects; use smaller subset for pipeline check only')
    p.add_argument('--data',default='data/real');p.add_argument('--out',default='runs/real')
    p.add_argument('--epochs',type=int,default=250);p.add_argument('--seed',type=int,default=42)
    p.add_argument('--cache-dir',help='Optional MOABB/MNE download location')
    a=p.parse_args()
    for d in (['iv2a','iv2b'] if a.dataset=='both' else [a.dataset]):
        T,E,OOF=acquire(d,a.data,a.subjects,a.seed,a.cache_dir)
        call('scripts/run_all.py','--dataset',d,'--train',T,'--eval',E,
             '--oof',OOF,'--out',Path(a.out)/d,'--epochs',a.epochs)
if __name__=='__main__':main()
