#!/usr/bin/env python3
"""One entry point for exported 96D T/E arrays and paper-output audit.
Requires original CIACNet embeddings. Never uses Session-E for model fit.
"""
import argparse, subprocess, sys
from pathlib import Path

def call(*args):
    print('RUN', ' '.join(map(str,args)),flush=True)
    subprocess.run([sys.executable,*map(str,args)],check=True)

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--train',required=True,help='Pre-exported CIACNet Session-T NPZ')
    p.add_argument('--eval',required=True,help='Pre-exported frozen CIACNet Session-E NPZ')
    p.add_argument('--out',default='runs/experiment')
    p.add_argument('--dataset',choices=['iv2a','iv2b'],required=True)
    p.add_argument('--oof',help='Row-aligned Session-T CIACNet OOF predictions')
    p.add_argument('--epochs',type=int,default=250)
    a=p.parse_args()
    out=Path(a.out); t=out/'discovery'; e=out/'replication'
    c=['-m','sae_eeg.cli','discover','--train',a.train,'--output',str(t),'--epochs',str(a.epochs)]
    if a.oof:c+=['--oof-predictions',a.oof]
    call(*c)
    call('-m','sae_eeg.cli','replicate','--eval',a.eval,'--frozen',str(t),'--output',str(e))
    call('-m','sae_eeg.paper_report','--discovery',str(t),'--replication',str(e),'--dataset',a.dataset,'--train-npz',a.train,'--out',str(out/'paper'))
if __name__=='__main__':main()
