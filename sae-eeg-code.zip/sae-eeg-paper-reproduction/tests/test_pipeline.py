import numpy as np
from sae_eeg.stats import bh, exact_fixed_margin_p
from sae_eeg.sae import TopKSAE, activations
from sae_eeg.cli import make_demo
from sae_eeg.io import load_npz


def test_bh_order_and_bounds():
    assert np.allclose(bh([.04, .001, .02]), [.04, .003, .03])


def test_fixed_margin_perfect_binary():
    y=np.array([0]*5+[1]*5)
    assert 0 < exact_fixed_margin_p(y,y) <= .01


def test_topk_shape():
    model=TopKSAE(k=16)
    z=activations(model,np.random.default_rng(3).normal(size=(12,96)).astype('float32'))
    assert z.shape==(12,96)
    assert np.all(np.sum(z>0,axis=1)<=16)


def test_demo_io(tmp_path):
    make_demo(tmp_path)
    x,s,y=load_npz(tmp_path/'session_T.npz')
    assert x.shape==(600,96) and len(s)==len(y)==600
