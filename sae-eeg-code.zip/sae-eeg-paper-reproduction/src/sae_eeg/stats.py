import numpy as np
from scipy.stats import hypergeom
from sklearn.metrics import roc_auc_score


def bh(pvalues):
    """Benjamini-Hochberg correction, retaining original order."""
    p = np.asarray(pvalues, dtype=float)
    if p.ndim != 1 or np.any(~np.isfinite(p)) or np.any((p < 0) | (p > 1)):
        raise ValueError('p-values must be finite in [0,1]')
    if len(p) == 0:
        return p.copy()
    order = np.argsort(p)
    q_sorted = np.minimum.accumulate((p[order] * len(p) / np.arange(1, len(p)+1))[::-1])[::-1]
    q = np.empty_like(q_sorted)
    q[order] = np.clip(q_sorted, 0, 1)
    return q


def balanced_accuracy(y, pred):
    y = np.asarray(y); pred = np.asarray(pred)
    return (np.mean(pred[y == 0] == 0) + np.mean(pred[y == 1] == 1)) / 2


def exact_fixed_margin_p(y, pred):
    """Exact one-sided null for BAcc by permuting predictions CONDITIONAL on both margins.

    With fixed true-class totals, fixed predicted-positive total K, TP is
    Hypergeometric(N, n_true_positive, K). The BAcc statistic increases with TP.
    Does NOT assume independent CV-fold accuracies.
    """
    y = np.asarray(y, dtype=int); pred = np.asarray(pred, dtype=int)
    if y.shape != pred.shape or not set(np.unique(y)).issubset({0, 1}) or not set(np.unique(pred)).issubset({0, 1}):
        raise ValueError('y and pred must be binary arrays with equal shapes')
    n = len(y); n_pos = int(y.sum()); n_pred_pos = int(pred.sum())
    if n_pos == 0 or n_pos == n or n == 0:
        raise ValueError('both true classes must be represented')
    tp = int(np.sum((y == 1) & (pred == 1)))
    return float(hypergeom.sf(tp - 1, n, n_pos, n_pred_pos))


def auc_for_direction(y, activation, preferred):
    if np.unique(y).size != 2:
        return float('nan')
    return float(roc_auc_score(y, activation if preferred == 1 else -activation))
