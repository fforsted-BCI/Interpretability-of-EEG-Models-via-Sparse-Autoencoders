"""Provisional feature discovery; physiology and intervention gates require other data."""
import numpy as np
from scipy.stats import mannwhitneyu
from sklearn.metrics import roc_auc_score
from .stats import bh


def discover(z, y, subject, *, min_auc=0.60, min_coverage=0.80,
             min_loso_auc=0.60, min_rate=0.02, max_rate=0.40):
    if len(np.unique(subject)) < 2:
        raise ValueError('Need >= 2 subjects for cross-subject discovery')
    rows = []
    subjects = np.unique(subject)
    for j in range(z.shape[1]):
        a = z[:, j]
        preferred = int(np.mean(a[y == 1]) >= np.mean(a[y == 0]))
        directed = a if preferred == 1 else -a
        auc = float(roc_auc_score(y, directed))
        # Two-sided nonparametric selectivity test (exploratory screening).
        p = float(mannwhitneyu(a[y == 1], a[y == 0], alternative='two-sided').pvalue)
        # Subject-level direction agreement. No pooled-trial pseudoreplication.
        subject_aucs = []
        for sid in subjects:
            ss = subject == sid
            if np.unique(y[ss]).size == 2:
                subject_aucs.append(float(roc_auc_score(y[ss], directed[ss])))
        coverage = float(np.mean(np.asarray(subject_aucs) > 0.5)) if subject_aucs else float('nan')
        # Held-out-subject average evaluation of the fixed, pooled feature axis;
        # NOT an independently refit SAE or a formal LOSO train/test experiment.
        mean_subject_auc = float(np.mean(subject_aucs)) if subject_aucs else float('nan')
        rate = float(np.mean(a > 0))
        rows.append({'feature': f'F{j:04d}', 'preferred': preferred, 'auc_t': auc,
                     'p': p, 'activation_rate': rate, 'coverage': coverage,
                     'subject_mean_auc': mean_subject_auc})
    qs = bh([r['p'] for r in rows])
    for r, q in zip(rows, qs):
        r['q_bh'] = float(q)
        r['candidate'] = bool(q < .05 and r['auc_t'] >= min_auc and r['coverage'] >= min_coverage
                              and r['subject_mean_auc'] >= min_loso_auc
                              and min_rate <= r['activation_rate'] <= max_rate)
        r['validated_mechanistic'] = False
    return rows
