from pathlib import Path
import json
import hashlib
import numpy as np


def load_npz(path, labelled=True):
    """Each row is a trial. Required keys: embeddings, subject, and (if labelled) y."""
    with np.load(path, allow_pickle=False) as a:
        required = {'embeddings', 'subject'} | ({'y'} if labelled else set())
        missing = required - set(a.files)
        if missing:
            raise ValueError(f'{path}: missing {sorted(missing)}')
        x = np.asarray(a['embeddings'], dtype=np.float32)
        s = np.asarray(a['subject']).astype(str)
        y = np.asarray(a['y'], dtype=np.int64) if labelled else None
    if x.ndim != 2 or x.shape[1] != 96 or not np.isfinite(x).all():
        raise ValueError('embeddings must be a finite N x 96 matrix')
    if len(s) != len(x) or len(x) == 0 or (labelled and (len(y) != len(x) or not set(np.unique(y)).issubset({0, 1}))):
        raise ValueError('incompatible lengths or labels (requires binary 0/1)')
    return x, s, y


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def write_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, sort_keys=True), encoding='utf-8')
