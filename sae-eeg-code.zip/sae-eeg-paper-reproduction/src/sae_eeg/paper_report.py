
from __future__ import annotations
import argparse,json,hashlib
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def save_table(df, name, folder):
    df.to_csv(folder/(name+'.csv'),index=False)
    try: (folder/(name+'.tex')).write_text(df.to_latex(index=False,escape=True,float_format='%.4f'),encoding='utf-8')
    except Exception: pass

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--discovery',required=True);p.add_argument('--replication',required=True)
    p.add_argument('--train-npz',help='Session-T input NPZ for dictionary activation plots')
    p.add_argument('--dataset',choices=['iv2a','iv2b'],required=True);p.add_argument('--out',required=True)
    a=p.parse_args();t=Path(a.discovery);e=Path(a.replication);out=Path(a.out)
    tabs=out/'tables';figs=out/'figures';tabs.mkdir(parents=True,exist_ok=True);figs.mkdir(parents=True,exist_ok=True)
    inv=json.loads((Path(__file__).resolve().parents[2]/'paper'/'inventory.json').read_text())
    ledger=[]
    for typ,items in inv.items():
        for n,(description,requirement) in items.items():
            ledger.append(dict(type=typ,number=int(n),description=description,requirement=requirement,status='NOT_GENERATED',output=''))
    def register(kind,n,path,status='SCAFFOLD_PROXY_NOT_PAPER_REPRODUCTION'):
        entry=next(x for x in ledger if x['type']==kind and x['number']==n)
        entry['status']=status;entry['output']=str(path.relative_to(out))
    if (t/'competence.csv').exists():
        df=pd.read_csv(t/'competence.csv');save_table(df,'table07_competence_PROVISIONAL',tabs)
        register('tables',7,tabs/'table07_competence_PROVISIONAL.csv')
    if (t/'features_t.csv').exists():
        df=pd.read_csv(t/'features_t.csv');save_table(df,'table10_feature_screen_PROVISIONAL',tabs)
        register('tables',10,tabs/'table10_feature_screen_PROVISIONAL.csv')
        if 'feature' in df and len(df):
            val=next((k for k in ['auc_t','auc','auroc','oriented_auc'] if k in df.columns),None)
            if val:
                sub=df.nlargest(min(20,len(df)),val)
                fig,ax=plt.subplots(figsize=(10,5));ax.bar(sub['feature'].astype(str),sub[val]);ax.tick_params(axis='x',rotation=70)
                ax.set(ylabel=val,title='Session-T SAE feature selectivity (exploratory, not paper reproduction)');fig.tight_layout()
                f=figs/'figure06_class_selectivity_PROVISIONAL.png';fig.savefig(f,dpi=200);plt.close(fig);register('figures',6,f)
    # Figure 4 proxy: dictionary activation health from Session-T only.
    # Requires retained activations; never touches E when constructing plots.
    try:
        import joblib
        from .io import load_npz
        from .sae import load_model, activations
        summary=json.loads((t/'training_summary.json').read_text())
        # Only use an input path explicitly supplied by caller, never guess from hash.
        if a.train_npz:
            x,subjects,y=load_npz(a.train_npz)
            mask=np.isin(subjects,summary['competent_subjects'])
            model=load_model(t/'sae.pt')
            scaler=joblib.load(t/'t_scaler.joblib')
            z=activations(model,scaler.transform(x[mask]).astype('float32'))
            rates=(z>0).mean(axis=0)
            fig,ax=plt.subplots(figsize=(9,4))
            ax.hist(rates,bins=20)
            ax.set(xlabel='Session-T feature activation frequency',ylabel='Number of SAE features',
                   title='SAE dictionary activation health (scaffold only)')
            fig.tight_layout();f=figs/'figure04_activation_health_PROVISIONAL.png'
            fig.savefig(f,dpi=200);plt.close(fig);register('figures',4,f)
            health=pd.DataFrame([dict(n_features=z.shape[1],mean_active=float((z>0).sum(axis=1).mean()),
                 dead_features=int(np.sum(rates==0)),mean_activation_rate=float(rates.mean()),
                 status='scaffold_only_not_original_SAE_objective')])
            save_table(health,'table09_dictionary_health_PROVISIONAL',tabs)
            register('tables',9,tabs/'table09_dictionary_health_PROVISIONAL.csv')
    except Exception as exc:
        (out/'figure04_error.txt').write_text(repr(exc))
    if (e/'replication_e.csv').exists():
        df=pd.read_csv(e/'replication_e.csv');idx=13 if a.dataset=='iv2a' else 14
        name=f'table{idx:02d}_frozen_replication_DESCRIPTIVE_ONLY';save_table(df,name,tabs)
        register('tables',idx,tabs/(name+'.csv'))
    # These are explicit metadata, not experimental measured results.
    config=pd.DataFrame([{'latent_dim':96,'dictionary_dim':96,'top_k':16,'original_aux_k':32,
          'aux_k_implemented_in_scaffold':False,'source':'research paper configuration / scaffold limitation'}])
    save_table(config,'table05_SAE_configuration_not_fit_proof',tabs)
    register('tables',5,tabs/'table05_SAE_configuration_not_fit_proof.csv','CONFIG_ONLY')
    ledger_path=out/'COVERAGE_LEDGER.csv';pd.DataFrame(ledger).to_csv(ledger_path,index=False)
    report={'dataset':a.dataset,'discovery_directory':str(t),'replication_directory':str(e),
            'coverage':{k:sum(x['status']!='NOT_GENERATED' for x in ledger if x['type']==k) for k in ('tables','figures')},
            'caveat':'Outputs with PROVISIONAL/DESCRIPTIVE are not claims of manuscript reproduction. Missing original CIACNet, experimental outputs, interventions and physiological EEG prevent completion of all paper figures/tables.'}
    (out/'report.json').write_text(json.dumps(report,indent=2))
    print('Paper output audit:',ledger_path,'\n',json.dumps(report,indent=2))
if __name__=='__main__':main()
