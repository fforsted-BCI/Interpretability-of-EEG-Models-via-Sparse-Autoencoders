import numpy as np
from sklearn.metrics import roc_auc_score


def replicate(z, y, subject, frozen_features):
    rows = []
    for f in frozen_features:
        j = int(f['feature'][1:]); pref = int(f['preferred'])
        directed = z[:, j] if pref == 1 else -z[:, j]
        auc = float(roc_auc_score(y, directed))
        subaucs = [float(roc_auc_score(y[subject == sid], directed[subject == sid]))
                   for sid in np.unique(subject) if np.unique(y[subject == sid]).size == 2]
        rows.append({'feature': f['feature'], 'preferred_t_frozen': pref,
                     'auc_e': auc, 'subject_direction_consistency_e': float(np.mean(np.asarray(subaucs) > .5))
                     if subaucs else float('nan'), 'direction_preserved_e': bool(auc > .5),
                     'n_e': len(y)})
    return rows
