import argparse
import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from .io import load_npz, sha256, write_json
from .competence import subject_competence
from .sae import fit_sae, save_model, load_model, activations
from .discovery import discover
from .replicate import replicate


def make_demo(directory, seed=7):
    """Synthetic data to check pipeline wiring; not scientific evidence."""
    out = Path(directory); out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    for session, n in [('T', 150), ('E', 80)]:
        xs=[]; ss=[]; yy=[]
        for s in range(1, 5):
            y = np.tile([0, 1], n//2)
            rng.shuffle(y)
            x = rng.normal(size=(n, 96)).astype('float32')
            x[:, :8] += (2*y[:, None]-1) * (0.9 if s != 2 else 0.03)
            if session == 'E': x += rng.normal(0, .2, x.shape)
            xs.append(x); ss.extend([f'S{s:02d}']*n); yy.extend(y)
        np.savez_compressed(out/f'session_{session}.npz', embeddings=np.vstack(xs),
                            subject=np.array(ss), y=np.array(yy, dtype=np.int64))


def discovery_command(args):
    out = Path(args.output); out.mkdir(parents=True, exist_ok=True)
    x,s,y = load_npz(args.train)
    if args.oof_predictions:
        with np.load(args.oof_predictions, allow_pickle=False) as obj:
            if 'oof_pred' not in obj:
                raise ValueError('OOF file must contain oof_pred aligned rowwise to Session-T')
            oof = obj['oof_pred']
        if len(oof) != len(y): raise ValueError('OOF row count mismatch')
    else: oof = None
    competence = subject_competence(x,s,y,folds=args.folds,seed=args.seed,oof_predictions=oof)
    pd.DataFrame(competence).to_csv(out/'competence.csv', index=False)
    competent = [r['subject'] for r in competence if r['competent']]
    if len(competent) < 2:
        raise RuntimeError('Fewer than two competent subjects; cannot proceed (do not relax q or use Session-E)')
    mask = np.isin(s,competent)
    scaler = StandardScaler().fit(x[mask]); xt = scaler.transform(x[mask]).astype('float32')
    joblib.dump(scaler, out/'t_scaler.joblib')
    model, losses = fit_sae(xt,epochs=args.epochs,seed=args.seed,k=args.k)
    save_model(model,out/'sae.pt')
    z = activations(model,xt)
    features = discover(z,y[mask],s[mask])
    pd.DataFrame(features).to_csv(out/'features_t.csv', index=False)
    # Candidate is only a statistical screen, NOT physiology/causal validation.
    frozen = [{'feature': r['feature'], 'preferred': r['preferred']} for r in features if r['candidate']]
    write_json(out/'frozen_features.json',frozen)
    write_json(out/'training_summary.json', {'train_file_sha256':sha256(args.train),
               'oof_source': 'external_CIACNet' if oof is not None else 'logistic_probe_fallback',
               'competent_subjects':competent, 'n_retained':int(mask.sum()),
               'latent_dim':96,'dictionary_size':96,'top_k':args.k,'aux_k_requested':32,
               'aux_k_loss_implemented':False,'final_mse':losses[-1],
               'candidate_feature_count':len(frozen),'seed':args.seed,
               'warning':'Candidates are not physiology-grounded or causally validated.'})
    write_json(out/'freeze_manifest.json',{
        'stage':'Session-T frozen before Session-E evaluation',
        'scaler_sha256':sha256(out/'t_scaler.joblib'),
        'sae_sha256':sha256(out/'sae.pt'),
        'features_sha256':sha256(out/'frozen_features.json'),
        'competence_sha256':sha256(out/'competence.csv'),
        'train_sha256':sha256(args.train)})
    print('Session-T frozen artifacts:', out, '| candidate features:', len(frozen))


def replication_command(args):
    out=Path(args.frozen)
    manifest=json.loads((out/'freeze_manifest.json').read_text())
    for key, filename in [('scaler_sha256','t_scaler.joblib'),('sae_sha256','sae.pt'),
                          ('features_sha256','frozen_features.json'),('competence_sha256','competence.csv')]:
        if sha256(out/filename)!=manifest[key]:raise RuntimeError('Frozen artifact integrity violation: '+filename)
    x,s,y = load_npz(args.eval)
    scaler=joblib.load(out/'t_scaler.joblib')  # only load own trusted artifacts
    model=load_model(out/'sae.pt')
    frozen=json.loads((out/'frozen_features.json').read_text())
    competent=set(json.loads((out/'training_summary.json').read_text())['competent_subjects'])
    mask=np.isin(s, list(competent))
    if not np.any(mask):raise ValueError('No competent subjects found in Session-E')
    z=activations(model,scaler.transform(x[mask]).astype('float32'))
    rows=replicate(z,y[mask],s[mask],frozen) if frozen else []
    output=Path(args.output); output.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(rows,columns=['feature','preferred_t_frozen','auc_e','subject_direction_consistency_e',
                               'direction_preserved_e','n_e']).to_csv(output/'replication_e.csv',index=False)
    write_json(output/'replication_audit.json',{'eval_file_sha256':sha256(args.eval),
               'freeze_manifest_sha256':sha256(out/'freeze_manifest.json'),
               'n_e':int(mask.sum()),'n_frozen_features':len(frozen),
               'no_training_on_e':True,'no_reselection_on_e':True})
    print('Frozen Session-E replication:',output/'replication_e.csv')


def main():
    p=argparse.ArgumentParser(description='Strict SAE Session-T to Session-E pipeline')
    sub=p.add_subparsers(dest='command',required=True)
    a=sub.add_parser('demo');a.add_argument('--output',default='examples/data')
    a=sub.add_parser('discover');a.add_argument('--train',required=True);a.add_argument('--output',default='runs/discovery')
    a.add_argument('--oof-predictions',help='NPZ containing row-aligned Session-T CIACNet OOF predictions')
    a.add_argument('--folds',type=int,default=5);a.add_argument('--epochs',type=int,default=250)
    a.add_argument('--k',type=int,default=16);a.add_argument('--seed',type=int,default=42)
    a=sub.add_parser('replicate');a.add_argument('--eval',required=True);a.add_argument('--frozen',required=True)
    a.add_argument('--output',default='runs/replication')
    args=p.parse_args()
    if args.command=='demo':make_demo(args.output)
    elif args.command=='discover':discovery_command(args)
    else:replication_command(args)

if __name__=='__main__': main()
