"""Session-T subject-wise out-of-fold competence using a baseline linear probe.

This module can use externally produced CIACNet OOF predictions for manuscript-faithful
competence. The built-in probe is a runnable fallback and NOT the CIACNet decoder.
"""
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from .stats import exact_fixed_margin_p, balanced_accuracy, bh


def subject_competence(x, subject, y, folds=5, seed=42, oof_predictions=None):
    rows = []
    names = sorted(np.unique(subject))
    for sid in names:
        idx = np.flatnonzero(subject == sid)
        yy = y[idx]
        if np.unique(yy).size != 2 or min(np.bincount(yy, minlength=2)) < folds:
            raise ValueError(f'Subject {sid}: need >= {folds} observations per class')
        if oof_predictions is None:
            pp = np.full(len(idx), -1, dtype=int)
            cv = StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed)
            for tr, te in cv.split(x[idx], yy):
                clf = make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000, random_state=seed))
                clf.fit(x[idx][tr], yy[tr])
                pp[te] = clf.predict(x[idx][te])
            if np.any(pp == -1):
                raise RuntimeError('Incomplete OOF predictions')
        else:
            pp = np.asarray(oof_predictions)[idx]
        if not set(np.unique(pp)).issubset({0, 1}):
            raise ValueError('OOF predictions must be 0/1 for every trial')
        rows.append({'subject': str(sid), 'n': len(idx), 'oof_bacc': float(balanced_accuracy(yy, pp)),
                     'p_exact': exact_fixed_margin_p(yy, pp)})
    q = bh([r['p_exact'] for r in rows])
    for r, qq in zip(rows, q):
        r['q_bh'] = float(qq)
        r['competent'] = bool(qq < 0.05)
    return rows
