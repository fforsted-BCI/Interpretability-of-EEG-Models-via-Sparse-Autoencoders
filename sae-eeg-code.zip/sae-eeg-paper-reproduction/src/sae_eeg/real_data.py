"""Real BCI Competition IV-2a/2b acquisition and a leakage-controlled baseline.


from __future__ import annotations
import argparse, json, re
from pathlib import Path
import numpy as np
from scipy.signal import welch
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from .competence import subject_competence

BANDS=((4,8),(8,12),(12,16),(16,20),(20,26),(26,32))

def spectral_features(X, fs=250, windows=8):
    """Log band power in each channel/time window (real EEG; no labels used)."""
    X=np.asarray(X,dtype=np.float32)
    if X.ndim!=3: raise ValueError('Expected trial EEG (N,C,T)')
    n,c,t=X.shape
    if t < 500: raise ValueError('Epoch shorter than 2 seconds')
    cols=[]
    for a in np.array_split(np.arange(t),windows):
        if len(a)<100: raise ValueError('Too many time windows for epoch')
        freq, psd=welch(X[:,:,a],fs=fs,nperseg=min(250,len(a)),axis=-1)
        for low, high in BANDS:
            k=(freq>=low)&(freq<high)
            if not np.any(k): raise ValueError('Insufficient PSD frequency resolution')
            cols.append(np.log(np.maximum(psd[:,:,k].mean(axis=-1),1e-24)))
    return np.concatenate(cols,axis=1).astype('float32')

def oof_subjectwise(feat,y,sid,runs,seed=42):
    result=np.full(len(y),-1,dtype=np.int64)
    for s in np.unique(sid):
        ix=np.flatnonzero(sid==s); yy=y[ix]; rr=runs[ix]
        # Prefer run-disjoint OOF. Runs are not shared between subjects.
        if len(np.unique(rr))>=5:
            cv=GroupKFold(n_splits=5).split(feat[ix], yy, rr)
        else:
            cv=StratifiedKFold(n_splits=5,shuffle=True,random_state=seed).split(feat[ix], yy)
        for tr,te in cv:
            if len(np.unique(yy[tr]))<2: raise ValueError(f'Subject {s}: single-class OOF train fold')
            mod=make_pipeline(StandardScaler(),LogisticRegression(max_iter=3000,random_state=seed))
            mod.fit(feat[ix][tr], yy[tr]);result[ix[te]]=mod.predict(feat[ix][te])
    if np.any(result<0):raise RuntimeError('Incomplete OOF predictions')
    return result

def _session_index(s):
    m=re.match(r'^(\d+)',str(s))
    if m:return int(m.group(1))
    raise ValueError(f'Unrecognized MOABB session name {s!r}; refusing to guess T/E split')

def _dataset(dataset):
    from moabb.datasets import BNCI2014_001, BNCI2014_004
    from moabb.paradigms import MotorImagery
    d=BNCI2014_001() if dataset=='iv2a' else BNCI2014_004()
    p=MotorImagery(events=['left_hand','right_hand'],n_classes=2,resample=250,
                   fmin=4,fmax=40,tmin=0,tmax=4)
    return d,p

def acquire(dataset, output, subjects=None, seed=42, cache_dir=None):
    """Download actual recordings through MOABB, split original sessions and cache arrays.

    Fit the spectral scaler/PCA ONLY on competent Session-T trials. Session-E is
    transformed with these frozen parameters. Run-wise OOF competence is T-only.
    """
    import joblib
    from .io import write_json
    from moabb import set_download_dir
    out=Path(output);out.mkdir(parents=True,exist_ok=True)
    if cache_dir:set_download_dir(str(Path(cache_dir).expanduser().resolve()))
    d,p=_dataset(dataset)
    selection=list(range(1,10)) if subjects is None else [int(x) for x in subjects]
    if not selection or not set(selection).issubset(set(range(1,10))):
        raise ValueError('Subjects must be IDs 1..9')
    arrays={'T':[],'E':[]}; classes={'left_hand':0,'right_hand':1}
    for s in selection:
        print(f'Downloading/loading REAL {dataset} subject {s}/9 through MOABB...',flush=True)
        X,labels,meta=p.get_data(dataset=d,subjects=[s])
        if not {'subject','session','run'}.issubset(meta.columns):
            raise RuntimeError('MOABB metadata must contain subject/session/run')
        if X.shape[1]!=(22 if dataset=='iv2a' else 3):
            raise RuntimeError(f'Unexpected EEG channel count for {dataset}: {X.shape}')
        if X.shape[2]<900 or X.shape[2]>1100:
            raise RuntimeError(f'Unexpected epoch length {X.shape}; inspect MOABB crop parameters')
        unique=sorted(set(str(v) for v in meta.session),key=_session_index)
        expected=2 if dataset=='iv2a' else 5
        if len(unique)!=expected:
            raise RuntimeError(f'{dataset} subject{s}: expected {expected} sessions, found {unique}')
        ids=[_session_index(v) for v in unique]
        if len(set(ids)) != expected or ids!=list(range(expected)):
            raise RuntimeError(f'Unexpected session indices for subject {s}: {unique}')
        for part in ('T','E'):
            split=1 if dataset=='iv2a' else 3
            mask=np.array([(_session_index(v)<split)==(part=='T') for v in meta.session])
            ys=np.array([classes.get(str(v),-1) for v in np.asarray(labels)[mask]],dtype=np.int64)
            if np.any(ys<0):raise ValueError(f'Unknown MI labels {set(np.asarray(labels)[mask])}')
            if min(np.bincount(ys,minlength=2))<5:raise RuntimeError(f'Subject {s}: too few trials/class')
            feat=spectral_features(X[mask],fs=250,windows=8)
            localruns=np.array([f'S{s:02d}-{meta.session.iloc[i]}-{meta.run.iloc[i]}' for i in np.flatnonzero(mask)])
            arrays[part].append((feat,ys,np.full(len(ys),f'S{s:02d}'),localruns))
        print(f'  sessions={unique}, T={sum(len(x[1]) for x in arrays["T"] if len(x[1]))} accumulated',flush=True)
    packed={}
    for key in ('T','E'):
        packed[key]=tuple(np.concatenate([v[j] for v in arrays[key]]) for j in range(4))
    ft,yt,st,rt=packed['T'];fe,ye,se,re=packed['E']
    oof=oof_subjectwise(ft,yt,st,rt,seed=seed)
    # The competence test below receives genuine T-only, run-aware OOF predictions.
    # It never trains on or selects based on Session-E.
    rows=subject_competence(ft,st,yt,oof_predictions=oof)
    competent=[x['subject'] for x in rows if x['competent']]
    if len(competent)<2:raise RuntimeError('Fewer than 2 competent subjects; cannot train shared representation')
    keep=np.isin(st,competent)
    scaler=StandardScaler().fit(ft[keep]);zt=scaler.transform(ft);ze=scaler.transform(fe)
    if zt.shape[1]<96:raise RuntimeError('Spectral features <96; cannot construct 96D baseline')
    model=PCA(n_components=96,random_state=seed,svd_solver='randomized').fit(zt[keep]);et=model.transform(zt).astype('float32');ee=model.transform(ze).astype('float32')
    for part,emb,labels,subj,runs in [('T',et,yt,st,rt),('E',ee,ye,se,re)]:
        np.savez_compressed(out/f'{dataset}_{part}.npz',embeddings=emb,y=labels,subject=subj,run=runs,
             dataset=np.asarray(dataset),encoder=np.asarray('spectral_PCA96_BASELINE_NOT_CIACNET'))
    np.savez_compressed(out/f'{dataset}_OOF.npz',oof_pred=oof,subject=st,run=rt)
    joblib.dump({'scaler':scaler,'pca':model,'bands':BANDS,'windows':8},out/f'{dataset}_baseline_encoder.joblib')
    write_json(out/f'{dataset}_acquisition.json',{'dataset':dataset,'source':'MOABB real BNCI Competition IV recordings',
       'subjects':selection,'sessions_T':[0] if dataset=='iv2a' else [0,1,2],
       'sessions_E':[1] if dataset=='iv2a' else [3,4], 'n_T':len(yt),'n_E':len(ye),
       'n_channels':22 if dataset=='iv2a' else 3,'n_competent':len(competent),
       'competent_subjects':competent,'encoder':'spectral log-bandpower + T-fitted StandardScaler/PCA; NOT CIACNet',
       'oof':'run-disjoint, subject-specific T-only logistic baseline',
       'warning':'Original paper CIACNet/SAE weights and physiological analyses NOT reproduced by baseline mode.'})
    return out/f'{dataset}_T.npz',out/f'{dataset}_E.npz',out/f'{dataset}_OOF.npz'

def main():
    p=argparse.ArgumentParser(description='Acquire REAL BCI-IV-2a/2b via MOABB, never synthetic trials')
    p.add_argument('--dataset',choices=['iv2a','iv2b','both'],default='both')
    p.add_argument('--out',default='data/real');p.add_argument('--subjects',nargs='*',type=int)
    p.add_argument('--cache-dir');p.add_argument('--seed',type=int,default=42)
    a=p.parse_args()
    for d in (['iv2a','iv2b'] if a.dataset=='both' else [a.dataset]):
        acquire(d,a.out,a.subjects,a.seed,a.cache_dir)
if __name__=='__main__':main()
