"""Research software: EEG SAE Session-T discovery and frozen Session-E evaluation."""
__version__ = "0.1.0"
