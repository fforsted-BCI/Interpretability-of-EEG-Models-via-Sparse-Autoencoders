import copy
import numpy as np
import torch
from torch import nn


class TopKSAE(nn.Module):
    """96 -> 96 nonnegative Top-K SAE with tied-free linear decoder.

    AuxK is recorded in configuration but NOT implemented as an auxiliary dead-feature loss.
    This avoids accidentally presenting a different auxiliary objective as validated.
    """
    def __init__(self, dim=96, features=96, k=16):
        super().__init__()
        self.dim, self.features, self.k = dim, features, k
        self.encoder = nn.Linear(dim, features)
        self.decoder = nn.Linear(features, dim)
        nn.init.kaiming_uniform_(self.encoder.weight, a=5 ** 0.5)
        nn.init.normal_(self.decoder.weight, std=0.02)

    def encode(self, x):
        raw = torch.relu(self.encoder(x))
        ids = torch.topk(raw, self.k, dim=-1).indices
        active = torch.zeros_like(raw)
        return active.scatter(1, ids, raw.gather(1, ids))

    def decode(self, z):
        return self.decoder(z)

    def forward(self, x):
        z = self.encode(x)
        return self.decode(z), z


def fit_sae(x, *, epochs=250, batch_size=128, lr=0.001, seed=42, k=16):
    torch.manual_seed(seed)
    np.random.seed(seed)
    model = TopKSAE(k=k)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    a = torch.as_tensor(np.asarray(x, dtype=np.float32))
    gen = torch.Generator().manual_seed(seed)
    losses = []
    for _ in range(epochs):
        model.train()
        total = 0.0
        for ids in torch.randperm(len(a), generator=gen).split(batch_size):
            xb = a[ids]
            pred, _ = model(xb)
            loss = torch.mean((pred - xb)**2)
            optimizer.zero_grad(); loss.backward(); optimizer.step()
            total += float(loss.item()) * len(ids)
        losses.append(total / len(a))
    model.eval()
    return model, losses


@torch.no_grad()
def activations(model, x, batch_size=4096):
    a = torch.as_tensor(np.asarray(x, dtype=np.float32))
    return np.vstack([model.encode(chunk).cpu().numpy() for chunk in a.split(batch_size)])


def save_model(model, path):
    torch.save({'state_dict': model.state_dict(), 'dim': model.dim,
                'features': model.features, 'k': model.k}, path)


def load_model(path):
    # Only load checkpoints you trust. weights_only prevents arbitrary pickle objects.
    obj = torch.load(path, map_location='cpu', weights_only=True)
    model = TopKSAE(dim=obj['dim'], features=obj['features'], k=obj['k'])
    model.load_state_dict(obj['state_dict']); model.eval()
    return model
